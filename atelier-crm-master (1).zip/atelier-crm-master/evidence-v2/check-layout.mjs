// First-viewport comparisons for iteration 2. Uses the same immutable fixtures.
import assert from 'node:assert/strict'
import {mkdir,readFile} from 'node:fs/promises'
import {qa,start,session,widths,saveJSON} from './harness.mjs'
import {fixtureState} from './source.mjs'
import {pageGeometry} from './measure.mjs'
const stage=process.argv[2]||'before',folder=`${qa}/${stage}-populated/layout`
const run=await start(stage),results=[]
await mkdir(folder,{recursive:true})
const pages=[['dashboard','/dashboard','QA-SO-001'],['salesorders','/admin/orders','QA-SO-001'],['purchaseorders','/admin/purchase-orders','QA-PO-001'],['supplierinvoices','/admin/supplier-invoices','QA-INV-001'],['products','/admin/products','QA EXAMPLE Cloth 01']]
const baseline=stage==='after'?JSON.parse(await readFile(`${qa}/before-populated/layout/results.json`,'utf8')):null
if(baseline)assert.equal(baseline.fixtures.sha256,fixtureState().sha256,'Same fixture bytes as BEFORE')
try{
 for(const width of widths){
  const s=await session(run,{width})
  for(const [name,path,marker]of pages){
   const result={name,path,width,status:'pass'}
   try{
    await s.go(path,marker);await s.page.evaluate(()=>scrollTo(0,0));result.geometry=await pageGeometry(s.page)
    await s.page.screenshot({path:`${folder}/${name}-${width}-viewport.png`})
    if(baseline){
     const before=baseline.results.find(r=>r.name===name&&r.width===width).geometry
     const contentWidth=g=>g.main.width-parseFloat(g.padding.left)-parseFloat(g.padding.right)
     result.comparison={beforeRows:before.fullyVisibleRows,afterRows:result.geometry.fullyVisibleRows,beforeContentWidth:contentWidth(before),afterContentWidth:contentWidth(result.geometry),beforePageOverflow:Math.max(0,before.scrollWidth-width),afterPageOverflow:Math.max(0,result.geometry.scrollWidth-width)}
     assert.ok(result.comparison.afterPageOverflow<=result.comparison.beforePageOverflow+1,'No increased document horizontal overflow')
     assert.ok(result.comparison.afterContentWidth>=result.comparison.beforeContentWidth-1,'Usable content width does not shrink')
     // Row count is evidence for visual review, not a requirement to squeeze text.
    }
   }catch(e){result.status='fail';result.error=e.message}
   results.push(result);console.log(`${result.status.toUpperCase()} ${width} ${name}`)
  }
  const safety={pageErrors:s.errors,unmatched:s.api.unmatched,writes:s.api.writes(),externalBlocked:s.api.external}
  for(const r of results.filter(r=>r.width===width)){r.safety=safety;if(s.errors.length||s.api.unmatched.length||s.api.writes().length)r.status='fail'}
  await s.close();await saveJSON(`${folder}/results.json`,{stage,source:run.source,fixtures:fixtureState(),synthetic:true,results})
 }
}finally{await run.close()}
if(results.some(r=>r.status==='fail'))process.exitCode=1
