// TEST ONLY. Entirely invented QA/EXAMPLE records. No production data, credentials,
// mail, Xero calls, database, or HTTP server. Schema references are in README.md.
export const API_ORIGIN = 'http://qa-api.example.test:3001'
export const QA_PASSWORD = 'QA-EXAMPLE-NOT-A-CREDENTIAL-2026'
export const STAMP = '2026-09-14T09:00:00.000Z'
export const clone = value => structuredClone(value)

export function makeFixtures({long = false} = {}) {
  const n = long ? 60 : 9
  const users = Array.from({length:n}, (_,i) => ({id:101+i, name:`QA EXAMPLE Client ${String(i+1).padStart(2,'0')}`, email:`client${i+1}@example.test`, role:i%3===1?'trade':'customer', trade_approved:true, archived_at:null, created_at:STAMP, can_view_finance:false}))
  const applicant = {id:201,name:'QA EXAMPLE Applicant Studio',email:'applicant@example.test',role:'trade',trade_approved:false,archived_at:null,created_at:STAMP}
  const staff = {id:901,name:'QA Reviewer',email:'reviewer@example.test',role:'director',can_view_finance:true,report_access:{reports:true,finance:true},archived_at:null,created_at:STAMP}
  users.push(applicant,staff)
  const brands = Array.from({length:n},(_,i)=>({id:301+i,name:`QA EXAMPLE House ${String(i+1).padStart(2,'0')}`,slug:`qa-example-house-${i+1}`,currency:'EUR',country:'QA Example country',brand_code:`QA${i+1}`,supplier_id:701,story:'QA EXAMPLE synthetic house story, for layout review only.',website_url:null,image_url:null,logo_url:null,is_international:i%2===0,trade_only:true,bespoke:false,archived_at:null,featured_rank:i<2?i+1:null,product_count:3,collection_count:1}))
  const collections = brands.map((b,i)=>({id:401+i,name:`QA EXAMPLE Collection ${i+1}`,slug:`qa-example-collection-${i+1}`,brand_id:b.id,brand_name:b.name,description:'QA EXAMPLE collection.',image_url:null,archived_at:null,featured_rank:i<2?i+1:null}))
  const products = brands.map((b,i)=>({id:501+i,name:`QA EXAMPLE Cloth ${String(i+1).padStart(2,'0')}`,slug:`qa-example-cloth-${i+1}`,brand_id:b.id,brand_name:b.name,collection_id:401+i,collection_name:collections[i].name,product_type:'fabric',category:'fabric',currency:'NZD',product_range:'QA EXAMPLE Range',size:null,composition:'QA EXAMPLE 80% linen / 20% cotton',width:'140 cm',rubs:'40,000',application:'QA EXAMPLE upholstery',price_band:'QA EXAMPLE Band A',lead_time:'QA EXAMPLE 4–6 weeks',description:'QA EXAMPLE synthetic cloth description. This record exists only in the isolated browser harness.',retail_price_cents:18000+i*500,trade_price_cents:12000+i*400,hi_res_asset_url:null,show_on_website:true,archived_at:null,colourway_count:2,colourways:[0,1].map(k=>({id:1001+i*2+k,name:`QA EXAMPLE ${k?'Clay':'Linen'}`,sku:`QA-EXAMPLE-${i+1}-${k+1}`,tones:k?['#ad7662']:['#d4cab2'],image_url:null,archived_at:null,inventory:{unit:'metres',qty_available:'20.00',qty_reserved:'4.00'}}))}))
  const items = Array.from({length:n},(_,i)=>({id:601+i,supplier:'QA EXAMPLE Supplier',category:'fabric',code:`QA-RATE-${String(i+1).padStart(2,'0')}`,code_normalized:`QARATE${i+1}`,unit:'metre',wholesale_rate:'48.2500',currency:'EUR',product_range:'QA EXAMPLE House 01',description:`QA EXAMPLE supplier cloth ${i+1}`,contents:'QA EXAMPLE linen blend',width:'140 cm',repeat:'12 cm',vertical_repeat:'24 cm',duty_class:'QA-A',freight_class:'A',date_effective:'2026-09-01',source_file:'QA-EXAMPLE-fixture.csv',archived_at:null,discontinued_at:null,suspect:i===1}))
  const orders = Array.from({length:n},(_,i)=>({id:801+i,order_number:`QA-SO-${String(i+1).padStart(3,'0')}`,kind:i%3===1?'order_request':'manual',status:['requested','confirmed','paid','shipped'][i%4],currency:'NZD',created_at:STAMP,archived_at:null,client_name:users[i].name,client_email:users[i].email,contact_phone:null,user_id:users[i].id,trade_account_id:null,client_reference:'QA EXAMPLE guest room',customer_po_number:`QA-CLIENT-PO-${i+1}`,notes:'QA EXAMPLE synthetic order note.',sales_rep_user_id:901,sales_rep_name:staff.name,subtotal_cents:48000,shipping_cents:1500,total_cents:49500,discount_pct:0,xero_invoice_ref:i%4?'QA-XERO-EXAMPLE':null,tracking_url:null,reservation_state:'held',shipping_address:{name:users[i].name,line1:'QA EXAMPLE 1 Test Lane',city:'Example City',postal_code:'0000',country:'NZ'},lines:[{id:2001+i,colourway_id:1001+i*2,sku:`QA-EXAMPLE-${i+1}-1`,product_name:products[i].name,colourway_name:'QA EXAMPLE Linen',brand_name:brands[i].name,qty:'4.00',unit:'metres',unit_price_cents:12000,line_total_cents:48000,reservation_state:'held',cut_requirements:'QA EXAMPLE 2 × 2m'}]}))
  const inventory = products.map((p,i)=>({colourway_id:p.colourways[0].id,sku:p.colourways[0].sku,product_id:p.id,product_name:p.name,brand_name:p.brand_name,colourway_name:'QA EXAMPLE Linen',unit:'metres',qty_available:i===1?'2.00':'20.00',qty_reserved:i===1?'4.00':'4.00'}))
  const po = {id:1,po_number:'QA-PO-001',brand_id:301,brand_name:brands[0].name,supplier_id:701,supplier_name:'QA EXAMPLE Supplier',currency:'EUR',status:'sent',receipt_state:'part',qty_ordered:'12.00',qty_received:'4.00',qty_outstanding:'8.00',line_count:1,total_cost:'579.0000',unpriced_lines:0,created_at:STAMP,created_by_name:'QA Reviewer',sent_at:STAMP,expected_at:'2026-10-01T09:00:00.000Z',notes:'QA EXAMPLE purchase order; receiving does not move stock.',lines:[{id:3001,colourway_id:1001,sku:'QA-EXAMPLE-1-1',product_name:products[0].name,colourway_name:'QA EXAMPLE Linen',line_type:'goods',qty_ordered:'12.00',qty_received:'4.00',qty_outstanding:'8.00',receipt_state:'part',unit:'metres',unit_price:'48.2500',notes:'QA EXAMPLE line note',allocations:[],receipts:[{id:4001,qty:'4.00',received_at:STAMP,consignment_ref:'QA-EXAMPLE-CONSIGNMENT',notes:'QA EXAMPLE receipt',received_by_name:'QA Reviewer'}]}]}
  const invoice = {id:1,invoice_number:'QA-INV-001',supplier_id:701,supplier_name:'QA EXAMPLE Supplier',invoice_date:'2026-09-14',currency:'EUR',status:'received',notes:'QA EXAMPLE synthetic supplier invoice.',allocation_count:1,unstated_allocations:0,total_amount:'620.0000',freight_amount:'41.0000',duty_amount:null,fx_rate:'0.54821',allocated_amount:'579.0000',unallocated_amount:'41.0000',purchase_orders_cost:'579.0000',unpriced_purchase_orders:0,variance:'41.0000',created_at:STAMP,created_by_name:'QA Reviewer',purchase_orders:[{id:5001,purchase_order_id:1,po_number:po.po_number,brand_name:brands[0].name,purchase_order_status:'sent',purchase_order_created_at:STAMP,amount:'579.0000',total_cost:'579.0000',purchase_order_total_cost:'579.0000',created_at:STAMP,allocated_by_name:'QA Reviewer'}]}
  // Nine coherent synthetic documents; long-list runs use sixty. These are
  // read-model payloads, never real transactions or production-derived data.
  const purchaseOrders = Array.from({length:n},(_,i)=> {
    if(i===0) return po
    const status=['sent','draft','sent','closed','sent','cancelled'][i%6]
    const qty=12+i*3, received=status==='closed'?qty:status==='sent'?(i%2?0:4):0
    const receipt=received===qty?'full':received?'part':'none'
    const unitPrice=48.25+i*2, cost=(qty*unitPrice).toFixed(4)
    const created=new Date(Date.parse(STAMP)-i*86400000).toISOString()
    const line={...clone(po.lines[0]),id:3001+i,colourway_id:1001+i*2,
      sku:products[i].colourways[0].sku,product_name:products[i].name,
      qty_ordered:qty.toFixed(2),qty_received:received.toFixed(2),
      qty_outstanding:(qty-received).toFixed(2),receipt_state:receipt,
      unit_price:unitPrice.toFixed(4),receipts:received?[{...clone(po.lines[0].receipts[0]),id:4001+i,qty:received.toFixed(2)}]:[]}
    return {...clone(po),id:i+1,po_number:`QA-PO-${String(i+1).padStart(3,'0')}`,
      brand_id:brands[i].id,brand_name:brands[i].name,status,receipt_state:receipt,
      qty_ordered:line.qty_ordered,qty_received:line.qty_received,qty_outstanding:line.qty_outstanding,
      total_cost:cost,created_at:created,sent_at:['sent','closed'].includes(status)?created:null,
      expected_at:new Date(Date.parse('2026-10-01T09:00:00Z')+i*86400000).toISOString(),lines:[line]}
  })
  const supplierInvoices = Array.from({length:n},(_,i)=> {
    if(i===0) return invoice
    const purchase=purchaseOrders[i], cost=Number(purchase.total_cost)
    const status=['received','matched','disputed'][i%3]
    const variance=status==='matched'?0:status==='disputed'?95.5:41
    const total=cost+variance, allocated=status==='matched'?total:cost
    return {...clone(invoice),id:i+1,invoice_number:`QA-INV-${String(i+1).padStart(3,'0')}`,
      invoice_date:purchase.created_at.slice(0,10),created_at:purchase.created_at,status,
      total_amount:total.toFixed(4),freight_amount:variance.toFixed(4),
      allocated_amount:allocated.toFixed(4),unallocated_amount:(total-allocated).toFixed(4),
      purchase_orders_cost:cost.toFixed(4),variance:variance.toFixed(4),
      purchase_orders:[{...clone(invoice.purchase_orders[0]),id:5001+i,purchase_order_id:purchase.id,
        po_number:purchase.po_number,brand_name:purchase.brand_name,purchase_order_status:purchase.status,
        amount:allocated.toFixed(4),total_cost:cost.toFixed(4),purchase_order_total_cost:cost.toFixed(4)}]}
  })
  const mirrorBase = {guid:'qa-record',origin:'dynamics',imported_at:STAMP,overridden_fields:[],stale_fields:[],custom_fields:{},raw:{'QA EXAMPLE source':'Synthetic test row only'}}
  const account = {...mirrorBase,name:'QA EXAMPLE Historical Client',atelier_account_number:'QA-ACCT-001',customer_type:'Trade',owner:'QA Reviewer',primary_contact:'QA EXAMPLE Contact',primary_contact_email:'historic@example.test',email:'historic@example.test',main_phone:null,address1_city:'Example City',province:'QA EXAMPLE Region',territory:'QA EXAMPLE Territory',currency:'NZD',credit_limit:'5000',payment_terms:'QA EXAMPLE 20th following',status_reason:'Active'}
  const historicOrder = {...mirrorBase,number:'QA-HIST-SO-001',customer:account.name,reference:'QA EXAMPLE Historical job',order_date:STAMP,expected_delivery_date:'2026-10-01T09:00:00.000Z',owner:'QA Reviewer',contact:'historic@example.test',deliver_to:'QA EXAMPLE 1 Test Lane',pricing_type:'Trade',status_reason:'Invoiced',currency:'NZD',total_ex_gst:'1000.00',gst:'150.00',total_incl_gst:'1150.00'}
  return {users,applicant,staff,brands,collections,products,items,orders,inventory,po,invoice,purchaseOrders,supplierInvoices,account,historicOrder,xero:{configured:true,connected:true,grant_type:'authorization_code',org_name:'QA EXAMPLE Organisation'},applications:[{id:7001,user:applicant,business_name:applicant.name,created_at:STAMP,trading_name:'QA EXAMPLE Studio',business_email:applicant.email,accounts_email:'accounts@example.test',design_contact_name:'QA EXAMPLE Designer',design_contact_email:'design@example.test',terms_accepted:true,customer_full_name:'QA EXAMPLE Applicant Studio',signatory_name:'QA EXAMPLE Signatory'}]}
}

// Stateful in-memory responses make post-mutation GET and hard reload observable.
// Only declared writes are accepted. They NEVER leave this process.
export function createApi(options = {}) {
  const data = makeFixtures(options)
  const log = [], unmatched = [], external = [], native = []
  const controls = {deleteConflict:false,archivable:true,emailConflict:false,delayMs:0,failGet:null}
  const list = (key,rows,q) => {
    let out=rows.filter(r=>q.get('include_archived')==='true'||!r.archived_at)
    if(q.get('q')) out=out.filter(r=>JSON.stringify(r).toLowerCase().includes(q.get('q').toLowerCase()))
    if(q.get('role')) out=out.filter(r=>r.role===q.get('role'))
    if(q.get('segment')==='clients') out=out.filter(r=>['customer','trade'].includes(r.role))
    if(q.get('segment')==='staff') out=out.filter(r=>['director','backoffice'].includes(r.role))
    if(q.get('supplier_id')) out=out.filter(r=>String(r.supplier_id)===q.get('supplier_id'))
    if(q.get('from')) out=out.filter(r=>(r.invoice_date??r.created_at??'').slice(0,10)>=q.get('from'))
    if(q.get('to')) out=out.filter(r=>(r.invoice_date??r.created_at??'').slice(0,10)<=q.get('to'))
    if(q.get('brand_id')) out=out.filter(r=>String(r.brand_id)===q.get('brand_id'))
    if(q.get('status')) out=out.filter(r=>q.get('status')==='open'?['requested','confirmed','paid'].includes(r.status):r.status===q.get('status'))
    const total=out.length, limit=Number(q.get('limit')||total||50),page=Number(q.get('page')||1)
    return {[key]:out.slice((page-1)*limit,page*limit),meta:{total,page,limit}}
  }
  function answer(method,url,body) {
    const p=url.pathname,q=url.searchParams
    if(method==='OPTIONS') return {status:204,body:null}
    if(method==='GET') {
      if(controls.failGet && p===controls.failGet) return {status:503,body:{message:'QA EXAMPLE simulated unavailable API. No backend connected.'}}
      if(p==='/auth/me') return {body:{user:data.staff}}
      if(p==='/admin/dashboard') return {body:{sales_mtd:{value_cents:data.orders.filter(o=>['paid','shipped'].includes(o.status)).length*48000,currency:'NZD',mixed_currency:false,orders:data.orders.filter(o=>['paid','shipped'].includes(o.status)).length,unpriced_lines:0,from:'2026-09-01',statuses:['paid','shipped']},open_orders:{count:data.orders.filter(o=>['requested','confirmed','paid'].includes(o.status)).length,statuses:['requested','confirmed','paid']},inbound:{count:1,status:'sent',purchase_orders:[data.po]},recent_orders:data.orders.slice(0,5)}}
      if(p==='/admin/xero/status') return {body:{xero:data.xero}}
      if(p==='/admin/trade-applications') return {body:{applications:data.applications.map(a=>({...a,user:data.users.find(u=>u.id===a.user.id)}))}}
      for(const [path,key] of [['users','users'],['brands','brands'],['collections','collections'],['products','products'],['price-list-items','items'],['orders','orders'],['inventory','inventory']]) {
        if(p===`/admin/${path}`) return {body:list(key,data[key],q)}
      }
      if(p==='/admin/suppliers') return {body:{suppliers:[{id:701,name:'QA EXAMPLE Supplier',currency:'EUR',archived_at:null}]}}
      if(p==='/admin/purchase-orders') return {body:list('purchase_orders',data.purchaseOrders,q)}
      if(p==='/admin/supplier-invoices') return {body:list('supplier_invoices',data.supplierInvoices,q)}
      if(p==='/admin/legacy/accounts') return {body:list('items',[data.account],q)}
      if(p==='/admin/legacy/sales-orders') return {body:list('items',[data.historicOrder],q)}
      if(p==='/admin/shipping-rates') return {body:{rates:[{id:9001,zone:'QA EXAMPLE Metro',threshold_qty:'0.00',rate_cents:1500},{id:9002,zone:'QA EXAMPLE Metro',threshold_qty:'10.00',rate_cents:2500}]}}
      if(p==='/admin/purchase-orders/1') return {body:{purchase_order:data.po}}
      if(p==='/admin/supplier-invoices/1') return {body:{supplier_invoice:data.invoice}}
      if(p==='/admin/supplier-invoices/unbilled') return {body:{purchase_orders:[],meta:{total:0}}}
      if(p==='/admin/legacy/accounts/qa-record') return {body:{record:data.account}}
      if(p==='/admin/legacy/sales-orders/qa-record') return {body:{record:data.historicOrder}}
      if(p==='/admin/trade-accounts/by-guid/qa-record') return {status:404,body:{message:'QA EXAMPLE contacts have not been enabled.'}}
      if(/^\/admin\/(products|price-list-items)\/\d+\/price-history$/.test(p)) return {body:{changes:[]}}
      const product=p.match(/^\/admin\/products\/(\d+)$/)
      if(product) return {body:{product:data.products.find(r=>r.id===+product[1])}}
      // Exact descriptor envelope from reportBuilders.test.js; the R-01 row
      // keys sales_rep/orders are explicitly exercised there. No guessed cost,
      // attribution, currency, or other server columns are added to this read.
      if(p==='/admin/reports/sales-by-rep') return {body:{report:'sales-by-rep',title:'QA EXAMPLE Sales per owner',columns:[{key:'sales_rep',label:'Sales rep',kind:'text',finance:false},{key:'orders',label:'Orders',kind:'number',finance:false}],rows:[{sales_rep:'QA Reviewer',orders:data.orders.filter(o=>['paid','shipped'].includes(o.status)).length}],totals:null,meta:{filters:Object.fromEntries(q),rows_total:1,row_limit:200,truncated:false,masked_columns:[],coverage:{note:'QA EXAMPLE synthetic report fixture; only the row keys declared in the CRM contract tests are included.'}}}}
      if(p==='/admin/reports/revenue-lines') {
        const rows=data.orders.filter(o=>['paid','shipped'].includes(o.status)).map(o=>({order_number:o.order_number,client:o.client_name,brand_name:o.lines[0].brand_name,product_name:o.lines[0].product_name,currency:'NZD',qty:4,value_cents:48000}))
        return {body:{report:'revenue-lines',title:'QA EXAMPLE Orders placed',columns:[['order_number','Order','text'],['client','Client','text'],['product_name','Design','text'],['currency','Currency','text'],['qty','Quantity','number'],['value_cents','Sales','money']].map(([key,label,kind])=>({key,label,kind,finance:false})),rows,totals:{order_number:'QA EXAMPLE Total',qty:rows.length*4,value_cents:rows.length*48000},meta:{filters:Object.fromEntries(q),rows_total:rows.length,row_limit:200,truncated:false,masked_columns:[],coverage:{note:'QA EXAMPLE synthetic browser fixture. No real API or database connected.'}}}}
      }
    }
    if(method==='POST'&&p==='/admin/users') {
      if(!body.email?.endsWith('.test')) return {status:422,body:{message:'QA fixtures accept .test email only.'}}
      const user={...body,id:990,created_at:STAMP,archived_at:null,trade_approved:false}
      data.users.push(user);return {status:201,body:{user,temp_password:QA_PASSWORD}}
    }
    if(method==='POST'&&p==='/admin/xero/disconnect') {data.xero.connected=false;return {body:{xero:data.xero}}}
    if(method==='POST'&&p==='/admin/price-list-items/mark-discontinued') {
      for(const item of data.items)if(item.supplier===body.supplier&&item.category===body.category&&item.suspect)item.discontinued_at=STAMP
      // AdminPriceListItems consumes result.message, not invented counters.
      return {body:{result:{message:'QA EXAMPLE discontinued marks recorded for the synthetic supplier/category fixture.'}}}
    }
    if(method==='POST'&&p==='/admin/orders/801/decline') {
      const order=data.orders.find(o=>o.id===801);order.status='declined';order.reservation_state='released';return {body:{order}}
    }
    const rowMatch=p.match(/^\/admin\/(users|brands|products|price-list-items|orders|inventory|colourways)\/(\d+)(?:\/(archive|restore|reset-password))?$/)
    if(rowMatch) {
      const [,entity,id,verb]=rowMatch,key=entity==='price-list-items'?'items':entity
      const rows=entity==='colourways'?data.products.flatMap(p=>p.colourways):data[key]
      const row=rows?.find(r=>String(r.id??r.colourway_id)===id)
      const singular={users:'user',brands:'brand',products:'product',items:'item',orders:'order',inventory:'inventory',colourways:'colourway'}[key]
      if(!row) return {status:404,body:{message:'QA EXAMPLE fixture row not found.'}}
      if(method==='DELETE'&&!verb) {
        if(controls.deleteConflict) return {status:409,body:{message:'QA EXAMPLE cannot delete: this test row has linked history.',blockers:[{label:'QA EXAMPLE linked records',count:2}],archivable:entity==='inventory'?false:controls.archivable}}
        rows.splice(rows.indexOf(row),1);return {body:{deleted:true}}
      }
      if(method==='PATCH'&&!verb) {
        if(controls.emailConflict&&body.email) return {status:409,body:{message:'QA EXAMPLE email is already in use.'}}
        Object.assign(row,body);return {body:{[singular]:row}}
      }
      if(method==='POST'&&['archive','restore'].includes(verb)) {row.archived_at=verb==='archive'?STAMP:null;return {body:{[singular]:row}}}
      if(method==='POST'&&verb==='reset-password') return {body:{user:row,reset_email_sent:true,qa_notice:'SIMULATED ONLY. No email sent.'}}
    }
    if(method==='DELETE'&&p==='/admin/supplier-invoices/1/allocations/1') {data.invoice.purchase_orders=[];return {body:{supplier_invoice:data.invoice}}}
    unmatched.push({method,path:p});return {status:501,body:{message:`QA EXAMPLE unimplemented fixture: ${method} ${p}`}}
  }
  return {data,log,unmatched,external,native,controls,answer,writes:()=>log.filter(r=>!['GET','HEAD','OPTIONS'].includes(r.method))}
}
