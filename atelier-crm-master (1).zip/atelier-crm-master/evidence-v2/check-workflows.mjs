// Material changed risks only. No live API; all writes explicitly allow-listed.
import assert from 'node:assert/strict'
import {mkdir} from 'node:fs/promises'
import {qa,start,session,widths,saveJSON} from './harness.mjs'
import {fixtureState} from './source.mjs'
const run=await start('after'),folder=`${qa}/after-populated/workflows`,results=[]
await mkdir(folder,{recursive:true})
const button=(s,name)=>s.page.getByRole('button',{name,exact:true})
const orderReads=s=>s.api.log.filter(r=>r.method==='GET'&&r.path==='/admin/orders')
const params=s=>Object.fromEntries(new URLSearchParams(s.page.url().split('?')[1]||''))
async function readAfter(s,path,action){const response=s.page.waitForResponse(r=>new URL(r.url()).pathname===path&&r.request().method()==='GET');await action();await response;await s.page.waitForTimeout(75)}
async function check(width,name,fn,expectedWrites=[]){
 const s=await session(run,{width}),r={name,width,status:'pass'}
 try{r.evidence=await fn(s);assert.deepEqual(s.api.writes().map(({method,path,body})=>({method,path,body})),expectedWrites)}
 catch(e){r.status='fail';r.error=e.message;await s.page.screenshot({path:`${folder}/${name}-${width}-FAIL.png`}).catch(()=>{})}
 r.requests=s.api.log;r.pageErrors=s.errors;r.unmatched=s.api.unmatched;r.externalBlocked=s.api.external;r.native=s.api.native;r.writes=s.api.writes()
 if(s.errors.length||s.api.unmatched.length||s.api.native.length){r.status='fail';r.error??='Unknown fixture, page error, or native dialog'}
 results.push(r);console.log(`${r.status.toUpperCase()} ${width} ${name}${r.error?': '+r.error.split('\n')[0]:''}`)
 await s.close();await saveJSON(`${folder}/results.json`,{stage:'after',source:run.source,fixtures:fixtureState(),synthetic:true,results})
}
try{for(const width of widths){
 await check(width,'sales-filters-url-drafts-source-count',async s=>{
  await s.go('/admin/orders?q=QA-SO-001&from=2026-09-01&to=2026-09-30','QA-SO-001')
  const fields=[['Search orders','QA-SO-002'],['Filter by client','QA EXAMPLE Client 02'],['Filter by client reference','QA EXAMPLE guest room'],["Filter by the client's PO number",'QA-CLIENT-PO-2'],['Ordered on or after','2026-09-02'],['Ordered on or before','2026-09-29']]
  assert.equal(await s.page.getByLabel('Search orders',{exact:true}).inputValue(),'QA-SO-001')
  const originalURL=s.page.url(),readCount=orderReads(s).length
  for(const[label,value]of fields)await s.page.getByLabel(label,{exact:true}).fill(value)
  await s.page.waitForTimeout(150);assert.equal(orderReads(s).length,readCount,'Typing drafts does not fetch');assert.equal(s.page.url(),originalURL)
  await readAfter(s,'/admin/orders',()=>s.page.getByLabel('Filter by status',{exact:true}).selectOption('confirmed'))
  assert.equal(params(s).q,'QA-SO-001','Immediate status retains committed q')
  for(const[label,value]of fields)assert.equal(await s.page.getByLabel(label,{exact:true}).inputValue(),value,'Status does not erase typed drafts')
  await readAfter(s,'/admin/orders',()=>button(s,'Search').click())
  await s.page.getByText('QA-SO-002',{exact:true}).waitFor()
  assert.deepEqual(params(s),{q:'QA-SO-002',from:'2026-09-02',to:'2026-09-29',status:'confirmed'})
  const applied=Object.fromEntries(new URLSearchParams(orderReads(s).at(-1).query))
  for(const[k,v]of Object.entries({q:'QA-SO-002',client:'QA EXAMPLE Client 02',reference:'QA EXAMPLE guest room',po_number:'QA-CLIENT-PO-2',from:'2026-09-02',to:'2026-09-29',status:'confirmed'}))assert.equal(applied[k],v,`${k} reaches API on Search`)
  await readAfter(s,'/admin/orders',()=>button(s,'Clear').click());await s.page.getByText('QA-SO-001',{exact:true}).waitFor()
  assert.deepEqual(params(s),{});for(const[label]of fields)assert.equal(await s.page.getByLabel(label,{exact:true}).inputValue(),'')
  const beforeSource=orderReads(s).length,counts=[]
  for(const[source,count]of [['website',3],['office',6]]){
    await s.page.getByLabel('Filter by source',{exact:true}).selectOption(source)
    await s.page.getByText(`${count} of 9 on this page · 9 matching in total`,{exact:true}).waitFor()
    await s.page.getByText('Source is filtered on the orders already loaded — the endpoint has no source filter yet, so page through to see the rest.',{exact:true}).waitFor()
    assert.equal(orderReads(s).length,beforeSource,'Source filters the loaded page only');assert.deepEqual(params(s),{})
    counts.push({source,count})
  }
  return {draftsWriteNothing:true,statusRetainsDraft:true,applied,sourceCounts:counts,sourceNoApiFetch:true}
 })
 await check(width,'money-values-and-unallocated-variance',async s=>{
  await s.go('/dashboard','QA-SO-001')
  await s.page.getByText('$1,920.00',{exact:true}).waitFor()
  await s.page.getByText('EUR 579.00',{exact:true}).waitFor()
  const inbound=s.page.locator('main a[href="#/admin/purchase-orders/1"]');assert.equal(await inbound.count(),1)
  await inbound.focus();await s.page.keyboard.press('Enter');await s.page.waitForURL('**/#/admin/purchase-orders/1')
  await s.go('/admin/orders','QA-SO-001');assert.equal(await s.page.getByText('$495.00',{exact:true}).count(),9)
  await s.go('/admin/supplier-invoices','QA-INV-001')
  const row=s.page.getByRole('link',{name:'QA-INV-001',exact:true}).locator('xpath=ancestor::div[contains(@style,"grid-template-columns")][1]')
  await row.getByText('620.00 EUR',{exact:true}).waitFor();await row.getByText('41.00 EUR to allocate',{exact:true}).waitFor();await row.getByText('41.00 EUR over quote',{exact:true}).waitFor()
  await s.page.getByText('Fully allocated',{exact:true}).first().waitFor();await s.page.getByText('On quote',{exact:true}).first().waitFor()
  return {dashboardMtd:'$1,920.00',inbound:'EUR 579.00',salesTotal:'$495.00',invoiceTotal:'620.00 EUR',unallocated:'41.00 EUR',variance:'41.00 EUR',matchedAndDisputedVisible:true}
 })
 await check(width,'server-masked-costs-remain-absent',async s=>{
  s.api.data.staff.can_view_finance=false;s.api.data.staff.report_access.finance=false
  delete s.api.data.po.total_cost
  for(const row of s.api.data.supplierInvoices)for(const key of ['total_amount','freight_amount','duty_amount','fx_rate','allocated_amount','unallocated_amount','purchase_orders_cost','variance'])delete row[key]
  await s.go('/dashboard','QA-PO-001')
  assert.equal(await s.page.getByText('EUR 579.00',{exact:true}).count(),0)
  await s.page.locator('[title="Supplier spend — not available on your access"]').waitFor()
  await s.go('/admin/supplier-invoices','QA-INV-001')
  await s.page.getByText('Money figures are not shown on your access — totals, allocation amounts and the variance are finance-gated. The bills themselves are still navigable.',{exact:true}).waitFor()
  for(const label of ['Total','Unallocated','Variance'])assert.equal(await s.page.locator('main').getByText(label,{exact:true}).count(),0)
  assert.equal(await s.page.getByText('620.00 EUR',{exact:true}).count(),0)
  assert.equal(await s.page.getByRole('link',{name:'QA-INV-001',exact:true}).count(),1)
  await s.page.screenshot({path:`${folder}/supplier-invoices-masked-${width}.png`})
  return {dashboardSupplierCostMasked:true,invoiceMoneyColumnsAbsent:true,documentsNavigable:true}
 })
 await check(width,'po-plan-dismiss-replan-generate',async s=>{
  s.api.controls.planFlow={plans:0,generated:0}
  await s.go('/admin/purchase-orders','QA-PO-001')
  const panel=s.page.locator('details').filter({hasText:'Raise from open demand'}),summary=panel.locator('summary')
  assert.equal(await panel.evaluate(el=>el.open),false)
  assert.equal(await s.page.getByRole('button',{name:'Raise 1 purchase order',exact:true}).count(),0,'No generate action before a plan')
  await summary.focus();await s.page.keyboard.press('Enter')
  await panel.getByRole('button',{name:'Plan today’s demand',exact:true}).click()
  await panel.getByText('1 purchase order would be raised, and 1 house cannot be ordered from, from 2 open sales-order lines.',{exact:true}).waitFor()
  await panel.getByText('QA EXAMPLE House 02 needs a linked supplier.',{exact:true}).waitFor()
  assert.equal(s.api.controls.planFlow.generated,0)
  await panel.getByRole('button',{name:'Dismiss',exact:true}).click()
  assert.equal(await s.page.getByRole('button',{name:'Raise 1 purchase order',exact:true}).count(),0)
  assert.equal(s.api.writes().length,1,'Dismiss only clears local preview')
  await panel.getByRole('button',{name:'Plan today’s demand',exact:true}).click()
  const raise=panel.getByRole('button',{name:'Raise 1 purchase order',exact:true});await raise.waitFor()
  await readAfter(s,'/admin/purchase-orders',()=>raise.click())
  await s.page.getByText('QA-PO-GENERATED',{exact:true}).waitFor()
  assert.equal(s.api.controls.planFlow.generated,1);assert.equal(s.api.data.purchaseOrders.length,10)
  assert.equal(await s.page.getByRole('button',{name:'Raise 1 purchase order',exact:true}).count(),0,'Successful generation clears preview')
  return {planRequests:2,generateRequests:1,previewedHouseIds:[301],blockedHouseVisible:true,dismissNoGenerate:true,newSyntheticOrderVisible:true}
 },[{method:'POST',path:'/admin/purchase-orders/plan',body:{}},{method:'POST',path:'/admin/purchase-orders/plan',body:{}},{method:'POST',path:'/admin/purchase-orders/generate',body:{brand_ids:[301]}}])
}}finally{await run.close()}
console.log(`${results.filter(r=>r.status==='pass').length}/${results.length} workflow checks passed`)
if(results.some(r=>r.status==='fail'))process.exitCode=1
