// User-confirmed scope. Other measured headers are informational only; they
// must never motivate production changes or fail the final layout gate.
export const LAYOUT_GATES = Object.freeze([
  'orders-sticky-header',
  'rates-sticky-header',
  'stock-sticky-header',
  'products-editor-footer',
  'rates-editor-footer',
  'orders-editor-footer',
])
export const isLayoutGate = name => LAYOUT_GATES.includes(name)
