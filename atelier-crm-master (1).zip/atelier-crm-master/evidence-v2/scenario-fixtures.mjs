// Explicit opt-in scenarios only. Screenshot fixture bytes remain frozen.
export const PLAN_REFUSAL='QA EXAMPLE planning unavailable. Retry the preview; no purchase orders were raised.'
export function scenarioResponse(controls,method,url,body,data) {
  if(controls.planRefusal&&method==='POST'&&url.pathname==='/admin/purchase-orders/plan')
    return {status:503,body:{message:PLAN_REFUSAL}}
  const flow=controls.planFlow
  if(flow&&method==='POST'&&url.pathname==='/admin/purchase-orders/plan') {
    flow.plans=(flow.plans??0)+1
    return {body:{plan:{candidate_lines:2,groups:[{brand_id:301,brand_name:'QA EXAMPLE House 01',supplier_id:701,supplier_name:'QA EXAMPLE Supplier',line_count:1,total_qty:'8.00',order_count:1,lines:[{colourway_id:1001,sku:'QA-EXAMPLE-1-1',product_name:'QA EXAMPLE Cloth 01',qty_ordered:'8.00',allocations:[{order_number:'QA-SO-001'}]}]}],blocked:[{brand_id:302,brand_name:'QA EXAMPLE House 02',message:'QA EXAMPLE House 02 needs a linked supplier.',order_line_ids:[2002]}]}}}
  }
  if(flow&&method==='POST'&&url.pathname==='/admin/purchase-orders/generate') {
    if(!flow.plans||JSON.stringify(body)!==JSON.stringify({brand_ids:[301]}))return {status:422,body:{message:'QA EXAMPLE generate must use exactly the previewed house.'}}
    const order={...structuredClone(data.po),id:991,po_number:'QA-PO-GENERATED',status:'draft',sent_at:null,qty_ordered:'8.00',qty_received:'0.00',qty_outstanding:'8.00',receipt_state:'none',total_cost:'386.0000',lines:[{...structuredClone(data.po.lines[0]),id:3991,qty_ordered:'8.00',qty_received:'0.00',qty_outstanding:'8.00',receipt_state:'none',receipts:[]}]}
    data.purchaseOrders.push(order);flow.generated=(flow.generated??0)+1
    return {body:{purchase_orders:[order],blocked:[],candidate_lines:2}}
  }
  return null
}
