// Long-list and editor-footer geometry, measured in Chromium at actual scroll
// positions. Only the user-confirmed scope in layout-scope.mjs is a gate.
import assert from 'node:assert/strict'
import {mkdir} from 'node:fs/promises'
import {qa,start,session,widths,saveJSON} from './harness.mjs'
import {LAYOUT_GATES,isLayoutGate} from './layout-scope.mjs'
const stage=process.argv[2]||'before',folder=`${qa}/${stage}-populated/sticky`
await mkdir(folder,{recursive:true})
const run=await start(stage),results=[]
const lists=[
  ['clients','/clients','QA EXAMPLE Client 01','Account'],
  ['houses','/admin/brands','QA EXAMPLE House 01','House'],
  ['products','/admin/products','QA EXAMPLE Cloth 01','Product'],
  ['rates','/admin/price-lists','QA-RATE-01','Supplier'],
  ['orders','/admin/orders','QA-SO-001','Order'],
  ['stock','/admin/stock','QA-EXAMPLE-1-1','SKU'],
]
const editors=[
  ['products','/admin/products','QA EXAMPLE Cloth 01','Edit','Save product'],
  ['rates','/admin/price-lists','QA-RATE-01','Edit','Save rate'],
  ['orders','/admin/orders','QA-SO-001','Open','Save order'],
]
async function measure(locator) {
  return locator.evaluate(el=>{
    const ancestors=[];let node=el
    while(node&&node!==document.documentElement){const cs=getComputedStyle(node);ancestors.push({tag:node.tagName,class:node.className,position:cs.position,overflowX:cs.overflowX,overflowY:cs.overflowY,top:cs.top,bottom:cs.bottom,rect:node.getBoundingClientRect().toJSON()});node=node.parentElement}
    return {rect:el.getBoundingClientRect().toJSON(),viewport:{width:innerWidth,height:innerHeight},scrollY,ancestors}
  })
}
async function check(width,name,fn) {
  const gate=isLayoutGate(name)
  const s=await session(run,{width,long:true}),result={name,width,gate,status:gate?'pass':'informational'}
  try{result.evidence=await fn(s,result)}catch(e){result.status=gate?'fail':'informational';result.error=e.message}
  result.errors=s.errors;result.unmatched=s.api.unmatched;result.writes=s.api.writes()
  if(s.errors.length||s.api.unmatched.length||s.api.writes().length){result.status=gate?'fail':'informational';result.error??='Unexpected page error/API request/write'}
  results.push(result);console.log(`${result.status.toUpperCase()} ${width} ${name}: ${result.error||'geometry checked'}`)
  await s.close();await saveJSON(`${folder}/results.json`,{stage,synthetic:true,rowsPerFixtureList:60,gateNames:LAYOUT_GATES,targetChecks:12,results})
}
try{for(const width of widths){
  for(const [name,path,marker,label] of lists.filter(([name])=>isLayoutGate(`${name}-sticky-header`)))await check(width,`${name}-sticky-header`,async(s,result)=>{
    await s.go(path,marker)
    const header=s.page.getByText(label,{exact:true}).first().locator('..')
    const initial=await measure(header),top=initial.rect.y+initial.scrollY
    const samples=[]
    for(const distance of [360,680]){
      await s.page.evaluate(y=>window.scrollTo(0,y),top+distance);await s.page.waitForTimeout(100)
      samples.push(await measure(header))
      await s.page.screenshot({path:`${folder}/${name}-long-scroll-${distance}-${width}.png`})
    }
    result.evidence={initial,samples,visibleWhileScrolling:samples.every(s=>s.rect.y>=0&&s.rect.bottom<=1000),holdsViewportPosition:Math.abs(samples[0].rect.y-samples[1].rect.y)<=2}
    if(result.gate){
      assert.ok(result.evidence.visibleWhileScrolling,'Header remains visible while list scrolls')
      assert.ok(result.evidence.holdsViewportPosition,'Header holds its viewport position over two scrolls')
    }
    assert.equal(result.writes?.length??0,0)
    return result.evidence
  })
  for(const [name,path,marker,expand,save]of editors)await check(width,`${name}-editor-footer`,async(s,result)=>{
    await s.go(path,marker);await s.page.getByRole('button',{name:expand,exact:true}).first().click()
    const control=s.page.getByRole('button',{name:save,exact:true}).first();await control.waitFor()
    const initial=await measure(control)
    // Begin with the natural footer near the bottom, then scroll upward into
    // the editor; a sticky footer must remain reachable in both positions.
    const naturalY=initial.rect.y+initial.scrollY,samples=[]
    for(const offset of [800,1080]){
      await s.page.evaluate(y=>window.scrollTo(0,Math.max(0,y)),naturalY-offset);await s.page.waitForTimeout(100)
      samples.push(await measure(control));await s.page.screenshot({path:`${folder}/${name}-editor-footer-${offset}-${width}.png`})
    }
    result.evidence={initial,samples}
    assert.ok(samples.some(s=>s.ancestors.some(a=>a.position==='sticky')),'Editor save action has a sticky ancestor')
    assert.ok(samples.every(s=>s.rect.y>=62&&s.rect.bottom<=1000),'Editor save action remains inside viewport')
    return result.evidence
  })
}}finally{await run.close()}
const gates=results.filter(r=>r.gate),failures=gates.filter(r=>r.status==='fail')
console.log(`${stage}: ${gates.length-failures.length}/${gates.length} target layout checks passed; ${results.length-gates.length} informational measurements`)
if(failures.length)process.exitCode=1
