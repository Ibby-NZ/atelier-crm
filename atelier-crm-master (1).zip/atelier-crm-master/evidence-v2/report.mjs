import {readFile,writeFile,access} from 'node:fs/promises'
import {qa} from './harness.mjs'
async function optional(path){try{return JSON.parse(await readFile(path,'utf8'))}catch(e){if(e.code==='ENOENT')return null;throw e}}
const before=await optional(`${qa}/before-populated/layout/results.json`),after=await optional(`${qa}/after-populated/layout/results.json`)
const rows=[]
for(const b of before?.results??[]){
 const a=after?.results.find(r=>r.name===b.name&&r.width===b.width)
 const describe=r=>r?{status:r.status,fullyVisibleRows:r.geometry.fullyVisibleRows,firstRowTop:r.geometry.rows[0]?.rect.y??null,firstRowHeight:r.geometry.rows[0]?.rect.height??null,rows:r.geometry.rows.map((row,i)=>({index:i+1,top:row.rect.y,bottom:row.rect.bottom,height:row.rect.height,fullyVisible:row.rect.top>=62&&row.rect.bottom<=r.geometry.innerHeight})),mainWidth:r.geometry.main.width,padding:r.geometry.padding}:null
 rows.push({page:b.name,width:b.width,before:describe(b),after:describe(a)})
}
const lines=['# Viewport row positions','', 'Measured at 1000 px viewport height, with the page at scrollY=0. Complete rows must lie between the 62 px sticky header and the bottom of the viewport. Counts measure density, not text legibility. Cell rectangles/clipping evidence remain in layout/results.json.','', '| Page | Width | BEFORE first row y / height | BEFORE complete rows | AFTER first row y / height | AFTER complete rows |','|---|---:|---:|---:|---:|---:|']
const position=r=>r?.firstRowTop==null?'—':`${r.firstRowTop.toFixed(1)} / ${r.firstRowHeight.toFixed(1)}`
for(const r of rows)lines.push(`| ${r.page} | ${r.width} | ${position(r.before)} | ${r.before.fullyVisibleRows} | ${r.after?position(r.after):'pending GO'} | ${r.after?.fullyVisibleRows??'pending GO'} |`)
lines.push('','Dashboard uses panels/cards; it is deliberately excluded from list-row recognition. All row coordinates are in row-positions.json.','')
await writeFile(`${qa}/row-positions.json`,JSON.stringify({createdAt:new Date().toISOString(),height:1000,afterAvailable:!!after,rows},null,2)+'\n')
await writeFile(`${qa}/row-positions.md`,lines.join('\n'))
console.log(`Reported ${rows.length} viewport cases; main AFTER ${after?'available':'pending GO'}`)
