import assert from 'node:assert/strict'
import {qa,start,session,saveJSON} from './harness.mjs'
import {API_ORIGIN} from './fixtures.mjs'
const run=await start('before'),s=await session(run),evidence=[]
try{
 await s.go('/dashboard','QA-SO-001')
 assert.deepEqual(s.api.unmatched,[]);assert.deepEqual(s.api.writes(),[])
 const initialExternal=s.api.external.length
 for(const [name,url,method,expected]of [
  ['known-fixture',`${API_ORIGIN}/auth/me`,'GET',200],
  ['unknown-api-read',`${API_ORIGIN}/QA-unimplemented`,'GET',501],
  ['unknown-api-write',`${API_ORIGIN}/QA-unimplemented`,'POST',501],
  ['external-read','https://qa-external.example.test/probe','GET','blocked'],
  ['external-write','https://qa-external.example.test/probe','POST','blocked'],
  ['other-local-origin','http://127.0.0.1:59999/probe','GET','blocked'],
  ['local-write',`${run.origin}/probe`,'POST','blocked'],
 ]){
  const outcome=await s.page.evaluate(async({url,method})=>{try{return(await fetch(url,{method})).status}catch{return'blocked'}},{url,method})
  assert.equal(outcome,expected,name);evidence.push({name,url,method,outcome})
 }
 assert.deepEqual(s.api.unmatched,[{method:'GET',path:'/QA-unimplemented'},{method:'POST',path:'/QA-unimplemented'}])
 assert.equal(s.api.external.length-initialExternal,4)
 const socketsBefore=s.api.external.length
 await s.page.evaluate(()=>new Promise(resolve=>{const ws=new WebSocket('ws://qa-websocket.example.test/socket');ws.onclose=()=>resolve();ws.onerror=()=>resolve();setTimeout(resolve,1000)}))
 assert.ok(s.api.external.slice(socketsBefore).some(e=>e.method==='WEBSOCKET'))
 evidence.push({name:'websocket',outcome:'blocked'})
 await saveJSON(`${qa}/safety-results.json`,{passed:true,synthetic:true,evidence,expectedUnknown:s.api.unmatched,externalBlocked:s.api.external,writes:s.api.writes()})
 console.log(`${evidence.length} isolation probes passed; all requests were fixture-fulfilled or blocked`)
}finally{await s.close();await run.close()}
