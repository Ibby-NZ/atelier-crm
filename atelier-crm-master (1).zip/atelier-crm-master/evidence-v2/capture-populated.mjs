// Standalone browser QA; deliberately NOT part of npm test or Vitest.
import {mkdir,access} from 'node:fs/promises'
import {qa,start,session,routes,widths,saveJSON} from './harness.mjs'
import {sourceState,fixtureState} from './source.mjs'
const stage=process.argv[2]||'before'
const folder=`${qa}/${stage}-populated`
await mkdir(folder,{recursive:true})
await mkdir(`${qa}/after-populated`,{recursive:true})
try {await access(`${folder}/manifest.json`);throw new Error(`Refusing to overwrite ${folder}/manifest.json; choose a new folder for a new run.`)}catch(e){if(e.code!=='ENOENT')throw e}
const run=await start(stage)
const manifest={stage,origin:run.origin,startedAt:new Date().toISOString(),sourceBefore:run.source,fixtures:fixtureState(),synthetic:true,backend:'Unavailable; all API responses intercepted in browser.',screenshots:[],failures:[],sessions:[]}
try {
  for(const width of widths) {
    const s=await session(run,{width})
    for(const [name,path,marker,expand,ready] of routes) {
      const index=s.api.log.length
      try {
        await s.go(path,marker)
        if(expand) {await s.page.getByRole('button',{name:expand,exact:true}).first().click();await s.page.getByRole('button',{name:ready,exact:true}).first().waitFor()}
        await s.page.evaluate(()=>window.scrollTo(0,0))
        await s.page.screenshot({path:`${folder}/${name}-${width}.png`,fullPage:true})
        await s.page.screenshot({path:`${folder}/${name}-${width}-viewport.png`})
        const metrics=await s.page.evaluate(()=>({innerWidth,innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight,main:document.querySelector('main')?.getBoundingClientRect().toJSON()}))
        manifest.screenshots.push({name,path,width,height:1000,capturedAt:new Date().toISOString(),file:`${name}-${width}.png`,viewportFile:`${name}-${width}-viewport.png`,metrics,requests:s.api.log.slice(index)})
        console.log(`CAPTURE ${width} ${name}`)
      }catch(e) {manifest.failures.push({name,path,width,message:e.message});console.log(`FAIL ${width} ${name}: ${e.message.split('\n')[0]}`);await s.page.screenshot({path:`${folder}/FAIL-${name}-${width}.png`}).catch(()=>{})}
    }
    manifest.sessions.push({width,errors:s.errors,consoleErrors:s.consoleErrors,unmatched:s.api.unmatched,externalBlocked:s.api.external,native:s.api.native,writes:s.api.writes()})
    await s.close()
  }
}finally {manifest.finishedAt=new Date().toISOString();try{manifest.sourceAfter=sourceState(stage);manifest.sourceUnchanged=manifest.sourceAfter.trackedSha256===manifest.sourceBefore.trackedSha256;if(!manifest.sourceUnchanged)manifest.failures.push({message:'Source changed during capture'})}catch(e){manifest.failures.push({message:e.message})}await saveJSON(`${folder}/manifest.json`,manifest);await run.close()}
console.log(`${stage}: ${manifest.screenshots.length} populated views / ${manifest.screenshots.length*2} files; ${manifest.failures.length} failures`)
if(manifest.failures.length||manifest.sessions.some(s=>s.errors.length||s.unmatched.length||s.writes.length))process.exitCode=1
