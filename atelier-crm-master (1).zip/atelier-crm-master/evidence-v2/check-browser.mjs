// Isolated browser acceptance suite, never imported by Vitest.
import assert from 'node:assert/strict'
import {mkdir} from 'node:fs/promises'
import {qa,start,session,widths,saveJSON} from './harness.mjs'
import {fixtureState} from './source.mjs'
import {PLAN_REFUSAL} from './scenario-fixtures.mjs'
import {selectors,core,destinations,ordersPages,activePages,sectionActions,labelledHistory,labelledDemo} from './nav-contract.mjs'
import {visibleGeometry,horizontalStrips} from './measure.mjs'
const stage=process.argv[2]||'before',folder=`${qa}/${stage}-populated/checks`
const run=await start(stage),results=[]
await mkdir(folder,{recursive:true})
const selected=process.env.QA_CHECKS?.split(',')
const resultsName=process.env.QA_RESULTS_NAME||'results.json'
if(!/^[a-zA-Z0-9._-]+\.json$/.test(resultsName))throw new Error('QA_RESULTS_NAME must be a plain .json filename')
const nav=s=>s.page.locator(selectors.nav)
const link=(scope,path)=>scope.locator(`a[href="#${path}"]`)
const focusIs=el=>el.evaluate(e=>e===document.activeElement)
const disclosures=s=>nav(s).locator('button[aria-expanded],summary')
const expanded=el=>el.evaluate(e=>e.tagName==='SUMMARY'?e.parentElement.open:e.getAttribute('aria-expanded')==='true')
async function setGroups(s,open){
  const controls=disclosures(s)
  for(let i=0;i<await controls.count();i++){
    const control=controls.nth(i)
    if(await expanded(control)!==open){await control.focus();await s.page.keyboard.press('Enter')}
  }
}
async function current(s,target){
  const active=nav(s).locator('[aria-current="page"]')
  const found=await active.evaluateAll(els=>els.map(el=>({tag:el.tagName,text:el.textContent.trim(),href:el.getAttribute('href')})))
  assert.equal(found.length,1,`Exactly one current sidebar destination; found ${JSON.stringify(found)}`)
  assert.equal(found[0].tag,'A');assert.equal(found[0].href,`#${target}`)
  assert.equal(await active.isVisible(),true,'Current destination is expanded and visible')
  return found[0]
}
async function check(width,name,fn,{kind='v2',height=1000,allowedWrites=[]}={}){
  if(selected&&!selected.includes(name))return
  const s=await session(run,{width,height}),result={name,width,height,kind,status:'pass'}
  try{result.evidence=await fn(s,result)}catch(e){result.status=stage==='before'&&kind==='v2'&&e.code==='ERR_ASSERTION'?'baseline-gap':'fail';result.error=e.message;await s.page.screenshot({path:`${folder}/${name}-${width}.png`}).catch(()=>{})}
  result.requests=s.api.log;result.unmatched=s.api.unmatched;result.pageErrors=s.errors;result.consoleErrors=s.consoleErrors;result.externalBlocked=s.api.external;result.writes=s.api.writes();result.native=s.api.native
  result.allowedWrites=allowedWrites
  const exactWrites=JSON.stringify(result.writes.map(({method,path,body})=>({method,path,body})))===JSON.stringify(allowedWrites)
  if(result.infrastructureFailure||s.errors.length||s.api.unmatched.length||!exactWrites||s.api.native.length){result.status='fail';result.error??='Page error, unknown fixture, write, or native dialog'}
  results.push(result);console.log(`${result.status.toUpperCase()} ${width} ${name}${result.error?': '+result.error.split('\n')[0]:''}`)
  await s.close()
  await saveJSON(`${folder}/${resultsName}`,{stage,source:run.source,fixtures:fixtureState(),synthetic:true,finishedAt:new Date().toISOString(),results})
}
try{
for(const width of widths){
  await check(width,'sidebar-direct-destinations',async s=>{
    await s.go('/dashboard','QA-SO-001');await setGroups(s,true)
    assert.equal(await nav(s).getAttribute('aria-label'),'Workspace')
    assert.equal(await s.page.locator('main').getAttribute('id'),'workspace-main')
    const observed=await nav(s).locator('a').evaluateAll(els=>els.map(el=>({href:el.getAttribute('href'),label:el.textContent.trim()})))
    assert.equal(observed.length,destinations.length,'Exactly 37 workspace destination links')
    const missing=destinations.filter(path=>!observed.some(a=>a.href===`#${path}`))
    assert.deepEqual(missing,[],`Missing direct sidebar links: ${missing.join(', ')}`)
    for(const path of destinations){assert.equal(await link(nav(s),path).count(),1,`One direct link for ${path}`);assert.equal(await link(nav(s),path).isVisible(),true)}
    return observed
  })
  await check(width,'core-three-always-visible',async s=>{
    await s.go('/dashboard','QA-SO-001');const evidence=[]
    for(const open of [false,true,false]){
      await setGroups(s,open);await nav(s).evaluate(el=>{el.scrollTop=0})
      for(const [label,path] of core){
        const target=link(nav(s),path);assert.equal(await target.count(),1,`${label} has its own link`)
        assert.equal((await target.innerText()).trim(),label)
        const geometry=await visibleGeometry(target);evidence.push({open,label,geometry})
        assert.ok(geometry.visible&&geometry.fullyWithinClips&&geometry.hit,`${label} remains in view with groups ${open?'open':'closed'}`)
      }
    }
    return evidence
  })
  await check(width,'precise-current-live-create-detail-mirror',async(s,result)=>{
    result.evidence=[]
    // Accumulate every mismatch so one bad route does not hide the remaining matrix.
    for(const [path,marker,target]of activePages){
      try{await s.go(path,marker);result.evidence.push({path,target,current:await current(s,target),pass:true})}
      catch(e){if(e.code!=='ERR_ASSERTION')result.infrastructureFailure=true;result.evidence.push({path,target,pass:false,error:e.message})}
    }
    const failures=result.evidence.filter(r=>!r.pass)
    assert.equal(failures.length,0,`${failures.length} active-route failures: ${failures.map(f=>f.path).join(', ')}`)
    return result.evidence
  })
  await check(width,'orders-section-create-actions-all-pages',async(s,result)=>{
    result.evidence=[]
    for(const [path,marker]of ordersPages){
      await s.go(path,marker)
      const actions=[]
      for(const [label,target]of sectionActions){
        const control=link(s.page.locator('main [aria-label="Page actions"]'),target).filter({hasText:label})
        const count=await control.count(),geometry=count===1?await visibleGeometry(control):null
        if(count===1)assert.equal(await control.locator('..').getAttribute('role'),'group','Page actions is an accessible group')
        const omitted=path===target||path==='/sales-orders/new',primary=path===target.replace(/\/new$/,'')
        const primaryClass=count===1?await control.evaluate(el=>el.classList.contains('ab-primary')):false
        actions.push({label,target,count,geometry,omitted,primary,primaryClass,pass:omitted?count===0:count===1&&geometry.visible&&geometry.fullyWithinClips&&geometry.hit&&primary===primaryClass})
      }
      result.evidence.push({path,actions})
    }
    const missing=result.evidence.flatMap(p=>p.actions.filter(a=>!a.pass).map(a=>({path:p.path,label:a.label})))
    assert.deepEqual(missing,[],`Missing or clipped section create actions: ${JSON.stringify(missing)}`)
    return result.evidence
  })
  await check(width,'no-horizontal-section-strips',async(s,result)=>{
    result.evidence=[]
    const pages=[...ordersPages,['/admin/products','QA EXAMPLE Cloth 01'],['/admin/price-lists','QA-RATE-01'],['/admin/stock','QA-EXAMPLE-1-1'],['/clients','client1@example.test'],['/reporting/library?r=orders','QA-SO-003']]
    for(const [path,marker]of pages){await s.go(path,marker);result.evidence.push({path,strips:await horizontalStrips(s.page)})}
    const remaining=result.evidence.filter(r=>r.strips.length)
    assert.deepEqual(remaining,[],`Horizontal section navigation remains on ${remaining.map(r=>r.path).join(', ')}`)
    return result.evidence
  })
  await check(width,'keyboard-group-disclosures',async s=>{
    await s.go('/dashboard','QA-SO-001')
    const controls=disclosures(s),count=await controls.count(),evidence=[]
    assert.ok(count>0,'Secondary navigation groups have keyboard disclosures')
    for(let i=0;i<count;i++){
      const control=controls.nth(i),label=(await control.innerText()).trim()
      assert.ok(label,'Disclosure has a visible accessible label')
      const structure=await control.evaluate(e=>({tag:e.tagName,id:e.getAttribute('aria-controls'),expanded:e.getAttribute('aria-expanded'),details:e.parentElement.tagName==='DETAILS'}))
      assert.ok(structure.details||(structure.tag==='BUTTON'&&structure.id&&structure.expanded!==null),'Native summary or button with aria-controls/aria-expanded')
      if(structure.id){assert.match(structure.id,/^nav-/);assert.equal(await s.page.locator(`[id="${structure.id}"]`).count(),1,'Controlled group exists')}
      const initial=await expanded(control)
      await control.focus();await s.page.keyboard.press('Shift+Tab');await s.page.keyboard.press('Tab')
      assert.equal(await focusIs(control),true,'Disclosure reached through normal Tab order')
      await s.page.keyboard.press('Enter');assert.equal(await expanded(control),!initial)
      await s.page.keyboard.press('Space');assert.equal(await expanded(control),initial)
      assert.equal(await focusIs(control),true,'Focus remains on disclosure')
      evidence.push({label,structure,enterAndSpace:true})
    }
    await setGroups(s,true)
    await s.page.screenshot({path:`${folder}/groups-expanded-${width}.png`})
    return evidence
  })
  await check(width,'collapsed-same-group-content-navigation',async s=>{
    await s.go('/clients','client1@example.test')
    const toggle=nav(s).locator('button[aria-controls="nav-clients"]')
    assert.equal(await toggle.count(),1,'Clients group disclosure exists')
    assert.equal(await toggle.getAttribute('aria-expanded'),'true')
    await toggle.focus();await s.page.keyboard.press('Enter')
    assert.equal(await toggle.getAttribute('aria-expanded'),'false')
    const mirror=link(s.page.locator('main'),'/clients/legacy')
    assert.equal(await mirror.count(),1,'Existing content link to Dynamics mirror remains')
    await mirror.focus();await s.page.keyboard.press('Enter');await s.page.waitForURL('**/#/clients/legacy')
    await s.page.getByText('QA EXAMPLE Historical Client',{exact:false}).first().waitFor()
    assert.equal(await toggle.getAttribute('aria-expanded'),'true','Changing route within a collapsed group reopens it')
    return {viaContentLink:true,current:await current(s,'/clients/legacy')}
  })
  if(stage==='after')await check(width,'po-collapsed-plan-error-visible',async s=>{
    await s.go('/admin/purchase-orders','QA-PO-001')
    const panel=s.page.locator('details').filter({has:s.page.locator('summary').filter({hasText:'Raise from open demand'})})
    assert.equal(await panel.count(),1);assert.equal(await panel.evaluate(el=>el.open),false,'Plan panel starts collapsed')
    const summary=panel.locator('summary'),initialSummary=await visibleGeometry(summary)
    assert.ok(initialSummary.visible&&initialSummary.fullyWithinClips,'Compact planning summary is discoverable in the initial viewport')
    await summary.focus();await s.page.keyboard.press('Enter');assert.equal(await panel.evaluate(el=>el.open),true)
    s.api.controls.planRefusal=true;s.api.controls.delayMs=1200
    const response=s.page.waitForResponse(r=>r.url().endsWith('/admin/purchase-orders/plan'))
    await panel.getByRole('button',{name:'Plan today’s demand',exact:true}).click()
    await summary.focus();await s.page.keyboard.press('Enter')
    assert.equal(await panel.evaluate(el=>el.open),false,'Can collapse pending plan')
    assert.equal((await response).status(),503)
    const error=s.page.getByText(PLAN_REFUSAL,{exact:true});await error.waitFor({state:'visible'})
    assert.equal(await error.evaluate(el=>!!el.closest('details')),false,'Plan refusal is outside collapsed disclosure')
    await error.scrollIntoViewIfNeeded();const geometry=await visibleGeometry(error)
    assert.ok(geometry.visible&&geometry.fullyWithinClips,'Refusal remains readable while collapsed')
    assert.equal(await panel.evaluate(el=>el.open),false)
    await s.page.screenshot({path:`${folder}/po-collapsed-plan-error-${width}.png`})
    return {planStatus:503,panelOpen:false,errorOutsidePanel:true,initialSummary,geometry}
  },{allowedWrites:[{method:'POST',path:'/admin/purchase-orders/plan',body:{}}]})
  await check(width,'historical-demo-labels',async s=>{
    await s.go('/dashboard','QA-SO-001');await setGroups(s,true);const evidence=[]
    for(const [kind,paths,pattern]of [['historical',labelledHistory,/histor|dynamics/i],['demo',labelledDemo,/demo|indicative/i]]){
      for(const path of paths){const el=link(nav(s),path);assert.equal(await el.count(),1,`${kind} link ${path} remains reachable`)
        const label=await el.innerText();assert.match(label,pattern,`${path} visibly labelled ${kind}`);evidence.push({kind,path,label})}
    }
    return evidence
  })
  await check(width,'core-links-keyboard-navigation',async s=>{
    const evidence=[]
    for(const [label,path]of core){await s.go('/dashboard','QA-SO-001');const target=link(nav(s),path)
      assert.equal(await target.count(),1);await target.focus();await s.page.keyboard.press('Enter');await s.page.waitForURL(`**/#${path}`)
      evidence.push({label,path,current:await current(s,path)})}
    return evidence
  })
}
await check(390,'phone-navigation-escape-focus',async s=>{
  await s.go('/dashboard','QA-SO-001')
  const trigger=s.page.locator(`button[aria-label="${selectors.phoneTrigger}"]`)
  await trigger.focus();await s.page.keyboard.press('Enter');await s.page.locator(selectors.phoneOpen).waitFor();await s.page.waitForTimeout(300)
  assert.equal(await trigger.getAttribute('aria-expanded'),'true','Trigger exposes open state')
  assert.equal(await trigger.getAttribute('aria-controls'),'workspace-navigation')
  assert.equal(await s.page.getByRole('dialog',{name:'Navigation'}).count(),1)
  assert.equal(await s.page.evaluate(sel=>document.querySelector(sel)?.contains(document.activeElement),selectors.sidebar),true,'Opening moves keyboard focus into navigation')
  const trace=[]
  for(const key of ['Shift+Tab','Tab',...Array(45).fill('Tab')]){await s.page.keyboard.press(key);const inside=await s.page.evaluate(sel=>document.querySelector(sel)?.contains(document.activeElement),selectors.sidebar);trace.push(inside);assert.equal(inside,true,'Keyboard focus stays in open phone navigation')}
  await s.page.keyboard.press('Escape');await s.page.locator(selectors.phoneOpen).waitFor({state:'hidden'});await s.page.waitForTimeout(300)
  assert.equal(await trigger.getAttribute('aria-expanded'),'false');assert.equal(await focusIs(trigger),true,'Escape restores focus to hamburger')
  await s.page.keyboard.press('Tab');assert.equal(await s.page.evaluate(sel=>document.querySelector(sel)?.contains(document.activeElement),selectors.sidebar),false,'Closed sidebar is excluded from Tab order')
  await trigger.focus();await s.page.keyboard.press('Enter');await s.page.locator(selectors.phoneOpen).waitFor()
  const target=link(nav(s),'/admin/purchase-orders');await target.focus();await s.page.keyboard.press('Enter');await s.page.waitForURL('**/#/admin/purchase-orders')
  await s.page.locator(selectors.phoneOpen).waitFor({state:'hidden'})
  assert.equal(await trigger.getAttribute('aria-expanded'),'false','Following a link closes drawer')
  await trigger.focus();await s.page.keyboard.press('Enter');await s.page.locator(selectors.phoneOpen).waitFor()
  const wordmark=link(s.page.locator(selectors.sidebar),'/dashboard').filter({hasText:'ATELIER'})
  assert.equal(await wordmark.count(),1);await wordmark.focus();await s.page.keyboard.press('Enter');await s.page.waitForURL('**/#/dashboard')
  await s.page.locator(selectors.phoneOpen).waitFor({state:'hidden'});assert.equal(await trigger.getAttribute('aria-expanded'),'false','Wordmark route change closes phone navigation')
  assert.equal(await focusIs(trigger),true,'Wordmark navigation restores hamburger focus')
  return {tabTrace:trace,escapeReturnsFocus:true,navigationCloses:true,wordmarkCloses:true}
},{height:844})
await check(390,'phone-user-menu',async s=>{
  await s.go('/dashboard','QA-SO-001')
  const avatar=s.page.getByRole('button',{name:'QA Reviewer — account menu',exact:true})
  await avatar.focus();await s.page.keyboard.press('Enter')
  const menu=s.page.getByRole('menu');await menu.waitFor()
  const geometry=await visibleGeometry(menu)
  assert.ok(geometry.visible&&geometry.fullyWithinClips,'Account menu fits phone viewport')
  assert.equal(await avatar.getAttribute('aria-expanded'),'true')
  await s.page.keyboard.press('Escape');await menu.waitFor({state:'hidden'})
  assert.equal(await avatar.getAttribute('aria-expanded'),'false');assert.equal(await focusIs(avatar),true)
  await s.page.keyboard.press('Enter');await menu.getByRole('menuitem',{name:'Manage users',exact:true}).focus()
  await s.page.keyboard.press('Enter');await s.page.waitForURL('**/#/users');await menu.waitFor({state:'hidden'})
  await s.page.getByText('client1@example.test',{exact:false}).first().waitFor({state:'attached'})
  const hamburger=s.page.locator('button[aria-label="Open navigation"]')
  await hamburger.click();await s.page.locator(selectors.phoneOpen).waitFor();await s.page.keyboard.press('Escape')
  await s.page.locator(selectors.phoneOpen).waitFor({state:'hidden'})
  await avatar.click();await menu.waitFor();await s.page.keyboard.press('Escape');await menu.waitFor({state:'hidden'})
  return {geometry,escapeCloses:true,manageUsersNavigates:true,usableAfterPhoneDrawer:true}
},{height:844})
}finally{await run.close()}
const failures=results.filter(r=>r.status==='fail'),gaps=results.filter(r=>r.status==='baseline-gap')
console.log(`${stage}: ${results.length-failures.length-gaps.length} passed; ${gaps.length} baseline gaps; ${failures.length} failures`)
if(failures.length)process.exitCode=1
