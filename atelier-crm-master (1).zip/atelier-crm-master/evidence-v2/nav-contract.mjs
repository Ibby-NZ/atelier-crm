// QA-owned expectation data. Update labels/selectors here when parent sends
// implementation details; requirements remain independent of application code.
export const selectors={sidebar:'.r-sidenav',nav:'.r-sidenav nav',phoneOpen:'.r-sidenav.r-open',phoneTrigger:'Open navigation'}
export const core=[['Sales orders','/admin/orders'],['Purchase orders','/admin/purchase-orders'],['Supplier invoices','/admin/supplier-invoices']]
export const destinations=[
  '/dashboard','/pricing','/catalogue','/admin/products','/admin/brands','/admin/collections','/admin/product-sheet',
  ...core.map(([,path])=>path),'/sales-orders','/admin/shipping',
  '/admin/reserves','/admin/reserves/report','/cutting','/admin/stock','/reserves',
  '/admin/suppliers','/reporting','/reporting/library','/reporting/insight',
  '/price-lists','/import','/admin/price-lists','/admin/freight','/price-lists/parameters',
  '/clients','/clients/applicants','/clients/legacy','/admin/samples','/admin/sample-loans',
  '/admin/showrooms','/admin/sample-orders','/sample-scanner','/admin/letters','/users','/admin/xero',
]
export const ordersPages=[
  ['/admin/orders','QA-SO-001','/admin/orders'],
  ['/admin/purchase-orders','QA-PO-001','/admin/purchase-orders'],
  ['/admin/supplier-invoices','QA-INV-001','/admin/supplier-invoices'],
  ['/admin/shipping','QA EXAMPLE Metro','/admin/shipping'],
  ['/sales-orders','QA-HIST-SO-001','/sales-orders'],
  ['/admin/orders/new','New sales order','/admin/orders'],
  ['/admin/purchase-orders/new','New purchase order','/admin/purchase-orders'],
  ['/admin/supplier-invoices/new','New supplier invoice','/admin/supplier-invoices'],
  ['/admin/purchase-orders/1','QA-PO-001','/admin/purchase-orders'],
  ['/admin/supplier-invoices/1','QA-INV-001','/admin/supplier-invoices'],
  ['/sales-orders/qa-record','QA-HIST-SO-001','/sales-orders'],
  ['/sales-orders/new','New Sales Order','/sales-orders'],
]
export const activePages=[
  ['/dashboard','QA-SO-001','/dashboard'],...ordersPages,
  ['/admin/orders?q=QA-SO-001','QA-SO-001','/admin/orders'],
  ['/admin/purchase-orders?status=sent','QA-PO-001','/admin/purchase-orders'],
  ['/purchase-orders/1','QA-PO-001','/admin/purchase-orders'],
  ['/purchase-orders/new','New purchase order','/admin/purchase-orders'],
  ['/admin/products','QA EXAMPLE Cloth 01','/admin/products'],
  ['/admin/brands','QA EXAMPLE House 01','/admin/brands'],
  ['/admin/collections','QA EXAMPLE Collection 1','/admin/collections'],
  ['/admin/stock','QA-EXAMPLE-1-1','/admin/stock'],
  ['/admin/price-lists','QA-RATE-01','/admin/price-lists'],
  ['/clients','client1@example.test','/clients'],
  ['/clients/applicants','applicant@example.test','/clients/applicants'],
  ['/users/applicants','applicant@example.test','/clients/applicants'],
  ['/clients/legacy','QA EXAMPLE Historical Client','/clients/legacy'],
  ['/clients/qa-record','QA EXAMPLE Historical Client','/clients/legacy'],
  ['/reporting/library?r=orders','QA-SO-003','/reporting/library'],
  ['/users','client1@example.test','/users'],
  ['/admin/xero','QA EXAMPLE Organisation','/admin/xero'],
]
export const sectionActions=[['New sales order','/admin/orders/new'],['New purchase order','/admin/purchase-orders/new']]
export const labelledHistory=['/sales-orders','/clients/legacy','/reserves','/price-lists/parameters']
export const labelledDemo=['/catalogue','/cutting','/reporting']
