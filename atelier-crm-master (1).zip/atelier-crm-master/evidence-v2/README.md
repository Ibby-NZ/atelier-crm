# Iteration 2 browser evidence

Final application: bb8a37f1659342824852299bb0c039dcf822237e. Baseline: iteration 1 at 6f22dab424e71c38beb47256f920bb8526cbe7df. The final c02d586 documentation commit changes no application code.

Start with INDEX.md for linked comparisons of all 28 views. Each stage has 56 viewport/full-page pairs at 1440 and 1024px, giving 224 PNGs across the main before/after sets. Manifests record matching fixture bytes and stable source fingerprints during capture. External fonts are blocked in both stages, so fallback fonts are consistent.

Final results in after-populated:

- checks/results.json: 22 passing navigation, header-action, keyboard, same-group navigation, phone menu and collapsed planning-error scenarios.
- layout/results.json: 10 passing comparisons at both desktop widths. Usable content width does not shrink and document overflow does not increase.
- sticky/results.json: 12 passing header/footer checks for Orders, Products, Supplier rates and Stock.

The screenshots and tests use synthetic QA/EXAMPLE records only. Every API call is intercepted on the exact qa-api.example.test origin. Unknown calls fail normal checks; all other external origins, service workers and WebSockets are blocked. No real API, mail or Xero transactions were performed. The two planning-error cases deliberately return a fixture refusal from the existing POST /admin/purchase-orders/plan request; they are not live writes. safety-results.json records eight passing isolation probes.

The original early shell preview and after-diagnostic-d8a4123 are retained as diagnostic history, not final acceptance. The latter predates the Sales filter-width fix. Its initial horizontal-strip detector mistakenly counted the required New sales order/New purchase order action group as navigation. The detector now excludes the explicitly labelled Page actions group; final checks pass. No production change was made to hide that harness failure.

The harness is development evidence, not a substitute for the connected atelier-api checks. Its server/source paths identify this review workspace, ports 5284/5285 and the supplied Chromium runtime. No dependency or browser was downloaded. Adjust those paths for another environment; the normal project test/build gates are npm test followed by npm run build.
