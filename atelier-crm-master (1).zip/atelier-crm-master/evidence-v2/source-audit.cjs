const fs = require('node:fs'), cp = require('node:child_process'), path = require('node:path')
const root = '/workspace/scratch/830c7f939e0f/crm-v2'
const parser = require(root + '/node_modules/@babel/parser')
const traverse = require(root + '/node_modules/@babel/traverse').default
const git = (...args) => cp.execFileSync('git', args, {cwd: root, encoding: 'utf8'})
const files = git('diff', '--name-only', '6f22dab', 'HEAD').trim().split('\n').filter(x => /\.(jsx|js)$/.test(x))
const unused = []
const parse = source => parser.parse(source, {sourceType: 'module', plugins: ['jsx']})
for (const file of files) {
  const ast = parse(fs.readFileSync(path.join(root, file), 'utf8'))
  traverse(ast, {ImportDeclaration(p) {for (const spec of p.node.specifiers) if (!p.scope.getBinding(spec.local.name)?.referenced) unused.push({file, name:spec.local.name})}})
}
function logicPrefix(source) {
  const declaration = parse(source).program.body.find(node => node.type === 'ExportDefaultDeclaration').declaration
  const statements = declaration.body.body
  const body = statements.slice(0, statements.findLastIndex(node => node.type === 'ReturnStatement'))
  return JSON.stringify(body, (key,value) => ['start','end','loc','extra','leadingComments','innerComments','trailingComments'].includes(key) ? undefined : value)
}
const screens = ['Dashboard','AdminOrders','AdminPurchaseOrders','AdminSupplierInvoices'].map(name => {
  const file = `src/screens/${name}.jsx`
  return {file, componentLogicUnchanged:logicPrefix(git('show', `6f22dab:${file}`)) === logicPrefix(fs.readFileSync(path.join(root,file),'utf8'))}
})
const protectedFilesChanged = git('diff', '--name-only', '6f22dab', 'HEAD', '--', 'src/data', 'src/store', 'src/auth', 'src/lib/api.js', 'src/theme.js', 'src/App.jsx', 'package.json', 'package-lock.json').trim()
console.log(JSON.stringify({head:git('rev-parse','HEAD').trim(), filesChecked:files.length, unusedImports:unused, screens, protectedFilesChanged},null,2))
if (unused.length || protectedFilesChanged || screens.some(x => !x.componentLogicUnchanged)) process.exitCode = 1
