// Real Chromium interactions with TEST-ONLY intercepted API responses.
// No npm-script integration and no DOM-testing dependency.
import assert from 'node:assert/strict'
import {mkdir} from 'node:fs/promises'
import {qa,start,session,widths,saveJSON} from './harness.mjs'
import {QA_PASSWORD} from './fixtures.mjs'
const stage=process.argv[2]||'after'
const folder=`${qa}/${stage}-populated/checks`
await mkdir(folder,{recursive:true})
const run=await start(stage)
const results=[]
const checkNames=process.env.QA_CHECKS?.split(',')
const resultsName=process.env.QA_RESULTS_NAME||'results.json'
const waitFor=async(fn,message)=>{for(let i=0;i<80;i++){if(await fn())return;await new Promise(r=>setTimeout(r,50))}throw new Error(message)}
const focusIs=async locator=>locator.evaluate(el=>el===document.activeElement)
const visible=async locator=>locator.isVisible()
const button=(page,name)=>page.getByRole('button',{name,exact:true})
const writes=s=>s.api.writes().map(({method,path,body})=>({method,path,body}))
async function dialogOpen(s,trigger) {
  await trigger.focus();await s.page.keyboard.press('Enter')
  await s.page.getByRole('dialog').waitFor()
  assert.equal(s.api.native.length,0,'No native confirm/prompt may fire')
}
async function modalContract(s,trigger) {
  const dialog=s.page.getByRole('dialog'),cancel=button(dialog,'Cancel')
  assert.equal(await focusIs(cancel),true,'Cancel gets initial focus')
  const structure=await dialog.evaluate(el=>({portalled:el.parentElement.parentElement===document.body,inert:document.querySelector('#root')?.inert,modal:el.getAttribute('aria-modal'),label:document.getElementById(el.getAttribute('aria-labelledby'))?.textContent}))
  assert.equal(structure.modal,'true');assert.ok(structure.label,'Dialog has an accessible label')
  // Record all focus movements before any assertion about topology.
  const controls=dialog.locator('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled)')
  const count=await controls.count(),focusTrace=[]
  await s.page.keyboard.press('Shift+Tab')
  focusTrace.push(await s.page.evaluate(()=>document.activeElement?.textContent))
  assert.equal(await focusIs(controls.last()),true,'Shift+Tab wraps from Cancel to last control')
  await s.page.keyboard.press('Tab')
  assert.equal(await focusIs(cancel),true,'Tab wraps to Cancel')
  for(let i=0;i<count+2;i++) {
    await s.page.keyboard.press('Tab')
    const observation=await dialog.evaluate(el=>({inside:el.contains(document.activeElement),text:document.activeElement?.textContent}))
    focusTrace.push(observation);assert.equal(observation.inside,true,'Tab focus stays inside dialog')
  }
  assert.equal(structure.portalled,true,'ConfirmDialog is portalled into body')
  assert.equal(structure.inert,true,'App root becomes inert')
  return {structure,focusTrace}
}
async function cancelAndReturn(s,trigger,how) {
  if(how==='Escape')await s.page.keyboard.press('Escape')
  else if(how==='backdrop')await s.page.mouse.click(4,4)
  else await button(s.page.getByRole('dialog'),'Cancel').click()
  await s.page.getByRole('dialog').waitFor({state:'hidden'})
  assert.equal(await focusIs(trigger),true,`${how} returns focus to trigger`)
  assert.equal(await s.page.locator('#root').evaluate(el=>el.inert),false,'App inert clears')
}
function hasReload(s,path,index) {return s.api.log.some(r=>r.index>index&&r.method==='GET'&&r.path===path)}
async function check(width,name,fn,options={}) {
  if(checkNames&&!checkNames.includes(name))return
  const s=await session(run,{width,...options})
  let result={name,width,height:options.height||1000,status:'pass'}
  try {result.evidence=await fn(s)}catch(e){result.status='fail';result.error=e.message;await s.page.screenshot({path:`${folder}/${name}-${width}-FAIL.png`}).catch(()=>{})}
  result.requests=s.api.log;result.native=s.api.native;result.unmatched=s.api.unmatched;result.pageErrors=s.errors;result.consoleErrors=s.consoleErrors;result.externalBlocked=s.api.external
  if(s.errors.length||s.api.unmatched.length||s.api.native.length){result.status='fail';result.error??='Page exception, unimplemented fixture, or native dialog observed'}
  results.push(result);console.log(`${result.status.toUpperCase()} ${width} ${name}${result.error?': '+result.error.split('\n')[0]:''}`)
  await s.close();await saveJSON(`${folder}/${resultsName}`,{stage,synthetic:true,backend:'No API/database connected; no external sends performed.',results})
}
const actions=[
  {name:'clients-archive',route:'/clients',marker:'QA EXAMPLE Client 01',trigger:'Archive',accept:'Archive',path:'/admin/users/101/archive',reload:'/admin/users'},
  {name:'users-archive',route:'/users',marker:'QA EXAMPLE Client 01',trigger:'Archive',accept:'Archive',path:'/admin/users/101/archive',reload:'/admin/users'},
  {name:'houses-archive',route:'/admin/brands',marker:'QA EXAMPLE House 01',trigger:'Archive',accept:'Archive',path:'/admin/brands/301/archive',reload:'/admin/brands'},
  {name:'products-archive',route:'/admin/products',marker:'QA EXAMPLE Cloth 01',trigger:'Archive',accept:'Archive',path:'/admin/products/501/archive',reload:'/admin/products'},
  {name:'rates-mark-discontinued',route:'/admin/price-lists',marker:'QA-RATE-01',trigger:'Mark discontinued',accept:'Mark discontinued',path:'/admin/price-list-items/mark-discontinued',body:{supplier:'QA EXAMPLE Supplier',category:'fabric'},reload:'/admin/price-list-items',prepare:async s=>{await button(s.page,'Mark discontinued').click();await s.page.getByLabel('Supplier',{exact:true}).fill('QA EXAMPLE Supplier')}},
  {name:'orders-decline',route:'/admin/orders',marker:'QA-SO-001',trigger:'Decline',accept:'Decline',path:'/admin/orders/801/decline',reload:'/admin/orders',prepare:async s=>{await button(s.page,'Open').first().click()}},
  {name:'applicant-decline',route:'/clients/applicants',marker:'QA EXAMPLE Applicant Studio',trigger:'Decline',accept:'Decline',path:'/admin/users/201/archive',reload:'/admin/users'},
  {name:'xero-disconnect',route:'/admin/xero',marker:'QA EXAMPLE Organisation',trigger:'Disconnect',accept:'Disconnect',path:'/admin/xero/disconnect',reload:'/admin/xero/status'},
  {name:'users-reset-link',route:'/users',marker:'QA EXAMPLE Client 01',trigger:'Email reset link',accept:'Email reset link',path:'/admin/users/101/reset-password',reload:'/admin/users'},
]
try {
 for(const width of widths) {
  // On baseline only the shared delete checks run; native archive replacements
  // are final expectations. This demonstrates known-negative controls without
  // dismissing every baseline native confirm dozens of times.
  if(stage==='after')for(const action of actions) await check(width,action.name,async s=>{
    await s.go(action.route,action.marker)
    if(action.prepare)await action.prepare(s)
    let trigger=button(s.page,action.trigger).first()
    await dialogOpen(s,trigger)
    assert.equal(writes(s).length,0,'Opening action must not write')
    const evidence=await modalContract(s,trigger)
    await cancelAndReturn(s,trigger,'Escape');assert.equal(writes(s).length,0)
    await dialogOpen(s,trigger);await cancelAndReturn(s,trigger,'backdrop');assert.equal(writes(s).length,0)
    await dialogOpen(s,trigger);await cancelAndReturn(s,trigger,'Cancel');assert.equal(writes(s).length,0)
    await dialogOpen(s,trigger);await button(s.page.getByRole('dialog'),action.accept).click()
    await waitFor(()=>s.api.writes().length===1,'Accept did not write once')
    assert.deepEqual(writes(s),[{method:'POST',path:action.path,body:action.body??{}}])
    const index=s.api.writes()[0].index
    if(action.reload) await waitFor(()=>hasReload(s,action.reload,index),'Mutation was not followed by list/status GET')
    if(action.name==='applicant-decline') await waitFor(()=>hasReload(s,'/admin/trade-applications',index),'Decline must reload applications as well as users')
    await s.page.reload();await s.page.locator('main').waitFor();await s.page.waitForTimeout(300)
    assert.equal(writes(s).length,1,'Hard reload must not repeat mutation')
    if(action.path.endsWith('/archive')) {
      const id=+action.path.split('/').at(-2)
      const entity=action.path.split('/')[2],key=entity==='price-list-items'?'items':entity
      const row=s.api.data[key].find(r=>r.id===id)
      assert.ok(row.archived_at,'Synthetic persisted state remains archived')
    }
    return {...evidence,reload:action.reload??'Applicants uses response reconciliation; hard reload checked.',writes:writes(s)}
  })
  await check(width,'delete-cancel-keyboard',async s=>{
    await s.go('/clients','QA EXAMPLE Client 01')
    const trigger=button(s.page,'Delete').first()
    await dialogOpen(s,trigger);assert.equal(writes(s).length,0)
    const evidence=await modalContract(s,trigger)
    await cancelAndReturn(s,trigger,'Escape');assert.equal(writes(s).length,0)
    await dialogOpen(s,trigger);await cancelAndReturn(s,trigger,'backdrop');assert.equal(writes(s).length,0)
    return evidence
  })
  await check(width,'delete-busy-success-reload',async s=>{
    await s.go('/clients','QA EXAMPLE Client 01')
    s.api.controls.delayMs=1800
    await dialogOpen(s,button(s.page,'Delete').first())
    await button(s.page.getByRole('dialog'),'Delete').click()
    await waitFor(()=>s.api.writes().length===1,'Delete request did not start')
    await s.page.keyboard.press('Escape');assert.equal(await visible(s.page.getByRole('dialog')),true,'Busy delete ignores Escape')
    await s.page.mouse.click(4,4);assert.equal(await visible(s.page.getByRole('dialog')),true,'Busy delete ignores backdrop')
    assert.equal(await button(s.page.getByRole('dialog'),'Delete').isDisabled(),true,'Busy Delete is disabled')
    await s.page.getByRole('dialog').waitFor({state:'hidden'})
    assert.deepEqual(writes(s),[{method:'DELETE',path:'/admin/users/101',body:null}])
    assert.equal(s.api.writes()[0].contentType,null,'DELETE sends no JSON content type')
    await waitFor(()=>hasReload(s,'/admin/users',s.api.writes()[0].index),'No GET following delete')
    await s.page.reload();await s.page.getByText('QA EXAMPLE Client 02',{exact:false}).first().waitFor()
    assert.equal(await s.page.getByText('client1@example.test',{exact:true}).count(),0,'Deleted row stays absent after reload')
    return {writes:writes(s),hardReload:true}
  })
  for(const [name,route,marker,archiveAllowed] of [
    ['delete-409-archive','/clients','QA EXAMPLE Client 01',true],
    ['delete-409-not-archivable','/clients','QA EXAMPLE Client 01',false],
    ['stock-delete-409','/admin/stock','QA-EXAMPLE-1-1',false],
  ]) await check(width,name,async s=>{
    await s.go(route,marker);s.api.controls.deleteConflict=true;s.api.controls.archivable=archiveAllowed
    await dialogOpen(s,button(s.page,'Delete').first())
    await button(s.page.getByRole('dialog'),'Delete').click()
    const dialog=s.page.getByRole('dialog')
    await dialog.getByText('QA EXAMPLE cannot delete: this test row has linked history.',{exact:true}).waitFor()
    assert.equal(await button(dialog,'Delete').count(),0,'No Delete retry on 409')
    assert.equal(await button(dialog,'Archive instead').count(),archiveAllowed?1:0,'Archive offered only when allowed')
    assert.equal(s.api.writes().length,1,'Only attempted DELETE before choosing alternative')
    const expectedDelete=route==='/admin/stock'?'/admin/inventory/1001':'/admin/users/101'
    assert.deepEqual(writes(s),[{method:'DELETE',path:expectedDelete,body:null}])
    await s.page.screenshot({path:`${folder}/${name}-${width}.png`})
    if(archiveAllowed) {
      await button(dialog,'Archive instead').click();await dialog.waitFor({state:'hidden'})
      assert.deepEqual(writes(s),[{method:'DELETE',path:'/admin/users/101',body:null},{method:'POST',path:'/admin/users/101/archive',body:{}}])
      assert.ok(hasReload(s,'/admin/users',s.api.writes()[1].index))
    }else{await button(dialog,'Cancel').click();assert.equal(writes(s).length,1)}
    return {writes:writes(s),archiveAllowed}
  })
  if(stage==='after') {
    for(const decision of ['Approve','Decline']) await check(width,`applicant-${decision.toLowerCase()}-reload-before-success`,async s=>{
      await s.go('/clients/applicants','QA EXAMPLE Applicant Studio')
      s.api.controls.delayMs=500;s.api.controls.delayReadsMs=900
      if(decision==='Decline'){await dialogOpen(s,button(s.page,decision));await button(s.page.getByRole('dialog'),decision).click()}
      else await button(s.page,decision).click()
      await waitFor(()=>s.api.writes().length===1,'Decision did not write')
      const expected={method:decision==='Approve'?'PATCH':'POST',path:decision==='Approve'?'/admin/users/201':'/admin/users/201/archive',body:decision==='Approve'?{trade_approved:true}:{}}
      assert.deepEqual(writes(s),[expected])
      // While the delayed mutation is pending every decision verb is disabled.
      for(const name of ['Approve','Decline','Review']) {
        const control=button(s.page,name).first()
        if(await control.count())assert.equal(await control.isDisabled(),true,`${name} disabled while pending`)
      }
      const index=s.api.writes()[0].index
      await waitFor(()=>hasReload(s,'/admin/users',index)&&hasReload(s,'/admin/trade-applications',index),'Both sources must reload after decision')
      assert.equal(await s.page.getByRole('status').count(),0,'Success toast must wait for both delayed reads')
      await s.page.getByRole('status').waitFor()
      const reads=s.api.log.filter(r=>r.index>index&&r.method==='GET')
      assert.ok(reads.some(r=>r.path==='/admin/users'&&r.fulfilled))
      assert.ok(reads.some(r=>r.path==='/admin/trade-applications'&&r.fulfilled))
      assert.equal(writes(s).length,1)
      s.api.controls.delayReadsMs=0
      await s.page.reload();await s.page.getByText('No trade accounts waiting for review.',{exact:true}).waitFor()
      return {writes:writes(s),reads,successAfterBothReads:true}
    })
    await check(width,'users-email-409-cancel-and-save',async s=>{
      await s.go('/users','QA EXAMPLE Client 01')
      let trigger=s.page.getByRole('button',{name:'Change sign-in email for client1@example.test',exact:true})
      await trigger.click();const input=s.page.getByLabel('New sign-in email for QA EXAMPLE Client 01',{exact:true})
      await input.fill('collision@example.test');await button(s.page,'Cancel').click()
      assert.equal(writes(s).length,0,'Cancelling a typed email writes nothing');assert.equal(await focusIs(trigger),true)
      await trigger.click();await input.fill('collision@example.test');s.api.controls.emailConflict=true
      await button(s.page,'Save email').click();const alerts=s.page.getByRole('alert').filter({hasText:'QA EXAMPLE email is already in use.'});await alerts.first().waitFor()
      assert.equal(await alerts.count(),1,'One refused email produces one API alert')
      assert.equal(await input.inputValue(),'collision@example.test','409 retains typed email')
      assert.deepEqual(writes(s),[{method:'PATCH',path:'/admin/users/101',body:{email:'collision@example.test'}}])
      await s.page.screenshot({path:`${folder}/users-email-409-${width}.png`})
      await button(s.page,'Cancel').click();assert.equal(writes(s).length,1)
      s.api.controls.emailConflict=false
      await trigger.click();await input.fill('changed@example.test');await button(s.page,'Save email').click()
      await input.waitFor({state:'hidden'});assert.equal(writes(s).length,2)
      assert.deepEqual(writes(s)[1],{method:'PATCH',path:'/admin/users/101',body:{email:'changed@example.test'}})
      assert.ok(hasReload(s,'/admin/users',s.api.writes()[1].index))
      const currentTrigger=s.page.getByRole('button',{name:'Change sign-in email for changed@example.test',exact:true})
      await waitFor(()=>focusIs(currentTrigger),'Successful email save restores focus after the roster reload')
      await s.page.reload();await s.page.getByRole('button',{name:'Change sign-in email for changed@example.test',exact:true}).waitFor()
      return {writes:writes(s),retainedAfter409:true,hardReload:true}
    })
    await check(width,'users-credential-and-short-toast',async s=>{
      await s.go('/users','QA EXAMPLE Client 01')
      await s.page.getByLabel('Name',{exact:true}).fill('QA EXAMPLE Newly Created')
      await s.page.getByLabel('Email',{exact:true}).fill('new-account@example.test')
      await button(s.page,'Add account').click()
      const notice=s.page.getByRole('region',{name:'New account credentials'}),toast=s.page.getByRole('status')
      await notice.getByText(QA_PASSWORD,{exact:true}).waitFor();await toast.waitFor()
      await s.page.waitForTimeout(350)
      const geometry=await toast.evaluate(el=>{const r=el.getBoundingClientRect(),c=getComputedStyle(el);return {rect:r.toJSON(),width:innerWidth,height:innerHeight,pointerEvents:c.pointerEvents,zIndex:c.zIndex,live:el.getAttribute('aria-live'),interactiveOverlap:[...document.querySelectorAll('main button, main input, main select')].map(b=>({text:b.textContent,rect:b.getBoundingClientRect()})).filter(b=>b.rect.width&&b.rect.left<r.right&&b.rect.right>r.left&&b.rect.top<r.bottom&&b.rect.bottom>r.top).map(b=>b.text)}})
      assert.ok(geometry.rect.x>=0&&geometry.rect.right<=width,'Toast stays inside viewport horizontally')
      assert.ok(geometry.rect.y>=0&&geometry.rect.bottom<=640,'Toast stays inside short viewport')
      assert.equal(geometry.pointerEvents,'none','Toast cannot block editor controls')
      assert.equal(geometry.live,'polite');assert.equal(geometry.zIndex,'50')
      await s.page.screenshot({path:`${folder}/toast-${width}-640.png`})
      await dialogOpen(s,button(s.page,'Delete').first())
      const modalZ=await s.page.getByRole('dialog').evaluate(el=>Number(getComputedStyle(el.parentElement).zIndex))
      assert.ok(modalZ>Number(geometry.zIndex),'Modal is above toast')
      await s.page.keyboard.press('Escape')
      await s.page.waitForTimeout(4000)
      assert.equal(await notice.getByText(QA_PASSWORD,{exact:true}).count(),1,'Credential survives longer than 3.6 seconds')
      assert.equal(await toast.count(),0,'Transient toast expires')
      assert.deepEqual(writes(s),[{method:'POST',path:'/admin/users',body:{email:'new-account@example.test',name:'QA EXAMPLE Newly Created',role:'customer'}}])
      return {geometry,modalZ,credentialObservedAfterMs:4350}
    },{height:640})
    await check(width,'dashboard-native-keyboard-links',async s=>{
      await s.go('/dashboard','QA-SO-001')
      const links=[
        ['QA-SO-001','/admin/orders?q=QA-SO-001'],['QA-PO-001','/admin/purchase-orders/1'],
      ],evidence=[]
      for(const [text,path] of links) {
        await s.go('/dashboard','QA-SO-001')
        const link=s.page.getByRole('link').filter({hasText:text}).first()
        assert.equal(await link.count(),1,`${text} is a native link`)
        const href=await link.getAttribute('href');assert.ok(href.endsWith(path))
        await link.focus();await s.page.keyboard.press('Shift+Tab');await s.page.keyboard.press('Tab')
        assert.equal(await focusIs(link),true);await s.page.keyboard.press('Enter');await s.page.waitForURL(`**/#${path}`)
        evidence.push({text,href,keyboardNavigated:true})
      }
      return evidence
    })
    await check(width,'report-rail-keyboard-selection',async s=>{
      await s.go('/reporting/library?r=orders','QA-SO-003')
      const rail=s.page.locator('.rl-rail'),target=rail.getByRole('button').filter({hasText:'Orders placed'}).first()
      assert.equal(await target.count(),1,'Orders report rail item is a button')
      const another=rail.getByRole('button').filter({hasText:'Sales per owner'}).first()
      await another.focus();await s.page.keyboard.press('Enter');await s.page.waitForTimeout(200)
      const selectedAway=s.page.url();assert.ok(!selectedAway.includes('r=orders'))
      await target.focus();await s.page.keyboard.press('Space');await s.page.waitForURL('**/#/reporting/library?r=orders')
      await s.page.getByText('QA-SO-003',{exact:false}).first().waitFor()
      return {selectedAway,selectedBack:s.page.url(),selectedState:await target.evaluate(el=>({pressed:el.getAttribute('aria-pressed'),current:el.getAttribute('aria-current')}))}
    })
    await check(width,'computed-keyboard-focus-brass',async s=>{
      await s.go('/clients','QA EXAMPLE Client 01')
      const evidence=[]
      for(const [kind,locator] of [
        ['input',s.page.getByRole('textbox',{name:'Search client accounts'})],
        ['select',s.page.getByLabel('Filter by role')],
        ['button',button(s.page,'New account')],
        ['checkbox',s.page.getByRole('checkbox',{name:'Show archived'})],
        ['link',s.page.getByRole('link',{name:'Dynamics mirror →'})],
      ]) {
        await locator.focus();await s.page.keyboard.press('Shift+Tab');await s.page.keyboard.press('Tab')
        assert.equal(await focusIs(locator),true,`${kind} reached by keyboard`)
        const style=await locator.evaluate(el=>{const c=getComputedStyle(el);return {focusVisible:el.matches(':focus-visible'),outline:c.outline,outlineColor:c.outlineColor,outlineWidth:c.outlineWidth,borderColor:c.borderColor}})
        assert.equal(style.focusVisible,true);assert.equal(style.outlineColor,'rgb(147, 121, 66)');assert.equal(style.outlineWidth,'1px')
        evidence.push({kind,...style})
      }
      await s.page.screenshot({path:`${folder}/focus-brass-${width}.png`});return evidence
    })
    await check(width,'read-error-and-reload',async s=>{
      s.api.controls.failGet='/admin/dashboard'
      await s.go('/dashboard','QA EXAMPLE simulated unavailable API. No backend connected.')
      assert.equal(writes(s).length,0)
      await s.page.screenshot({path:`${folder}/dashboard-error-${width}.png`})
      s.api.controls.failGet=null;await s.page.reload();await s.page.getByText('QA-SO-001',{exact:false}).first().waitFor()
      return {status503Shown:true,hardReloadRecovered:true,writes:writes(s)}
    })
  }
 }
}finally{await run.close()}
const failures=results.filter(r=>r.status==='fail')
console.log(`${stage}: ${results.length-failures.length}/${results.length} passed; ${failures.length} failed (synthetic browser API only)`)
if(failures.length)process.exitCode=1
