# Final QA summary — Atelier CRM iteration 2

**Complete and ready for packaging.** Captured app HEAD `bb8a37f`; later parent
commit `c02d586` changes handover docs only. BEFORE and AFTER manifests remain
unchanged, preserving their clean captured source states.

- **22/22 navigation/browser checks passed**, including 37 links at each width,
  exact active state, phone user menu/drawer, same-group reopening and both
  collapsed PO plan-refusal cases.
- **10/10 viewport layout checks passed.**
- **12/12 retained sticky header/footer checks passed.**
- **8/8 additional targeted filter, money/masking and PO-plan workflow checks passed.**
- **112 BEFORE PNGs and 112 final AFTER PNGs**, covering 28 views at two widths.
  Captures had zero errors, unknown API calls or writes; source stayed unchanged.

No material check is missing from the claimed 22/10/12 counts. The PO refusals
are delayed plan POST 503 cases at 1440 and 1024, not PO-list filter GET-refusal
cases; separate PO-list filter refusal coverage is not claimed. The full old
44-case browser regression suite and parent's pure test/build gates were not
rerun by this sidecar.

## Viewport counts

| Page | 1440 BEFORE → AFTER | 1024 BEFORE → AFTER |
|---|---:|---:|
| Sales orders | 5 → 5 | 2 → 3 |
| Purchase orders | 6 → 7 | 2 → 4 |
| Supplier invoices | 6 → 6 | 5 → 4 |
| Products | 4 → 6 | 3 → 3 |

No increased document or measured cell overflow. Invoice money-column overflow
was removed. Products' 1024 clipping is unchanged baseline behavior. Parent
accepted the visual tradeoffs at both widths. Exact y/height and row coordinates
are in `row-positions.md` and `row-positions.json`.

## Preserved diagnostic and detector correction

`after-diagnostic-d8a4123/` retains the initial AFTER set, including raw failures.
The no-horizontal-strip detector had mistaken the two Page actions create links
for tabs. QA now excludes the accessible Page actions group; no application fix
was needed. The focused corrected AFTER run passed both widths and the final
full navigation run passed all 22 checks. The final BEFORE negative control
still detects real strips on 15 pages at each width.

## Evidence

- Final images and manifest: `after-populated/`.
- Nav: `after-populated/checks/results.json`.
- Layout: `after-populated/layout/results.json`.
- Sticky: `after-populated/sticky/results.json`.
- Workflows: `after-populated/workflows/results.json`.
- Negative control: `before-populated/checks/strips-final-negative-control.json`.
- Full coverage/safety/reproduction notes: `README.md`.

All data and mutations were synthetic and intercepted. No app edits, dependency
installs, live API calls or agents were used. External traffic was blocked.
