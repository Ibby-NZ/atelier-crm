// Custom Vite configuration lives OUTSIDE both source repos. No .env is read.
import {createServer} from '../atelier-crm-master/node_modules/vite/dist/node/index.js'
import react from '../atelier-crm-master/node_modules/@vitejs/plugin-react/dist/index.js'
import {fileURLToPath} from 'node:url'
import {API_ORIGIN} from './fixtures.mjs'
const stage=process.argv[2]
if(!['before','after'].includes(stage)) throw new Error('Usage: node qa-v2/server.mjs before|after')
if(stage==='after'&&process.env.QA_V2_AFTER_GO!=='1') throw new Error('AFTER needs parent GO: QA_V2_AFTER_GO=1')
const root=fileURLToPath(new URL(stage==='before'?'../atelier-crm-master/':'../crm-v2/',import.meta.url))
const qa=fileURLToPath(new URL('./',import.meta.url))
const port=stage==='before'?5284:5285
const server=await createServer({configFile:false,root,envDir:qa,plugins:[react()],base:'./',cacheDir:`${qa}/vite-cache-${stage}`,define:{'import.meta.env.VITE_API_BASE_URL':JSON.stringify(API_ORIGIN)},server:{host:'127.0.0.1',port,strictPort:true,hmr:false,fs:{allow:[root,qa]}},logLevel:'warn'})
await server.listen()
console.log(`QA_READY http://127.0.0.1:${port}`)
for(const signal of ['SIGTERM','SIGINT']) process.on(signal,async()=>{await server.close();process.exit(0)})
