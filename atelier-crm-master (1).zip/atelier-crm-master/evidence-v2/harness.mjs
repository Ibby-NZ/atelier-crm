import {chromium} from '../atelier-crm-master/node_modules/playwright-core/index.mjs'
import {spawn} from 'node:child_process'
import {mkdir,writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'
import {API_ORIGIN,createApi} from './fixtures.mjs'
import {sourceState} from './source.mjs'
import {scenarioResponse} from './scenario-fixtures.mjs'
export const qa=fileURLToPath(new URL('./',import.meta.url))
export const widths=[1440,1024]
export const routes=[
  ['dashboard','/dashboard','QA-SO-001'],
  ['salesorders','/admin/orders','QA-SO-001'],
  ['purchaseorders','/admin/purchase-orders','QA-PO-001'],
  ['supplierinvoices','/admin/supplier-invoices','QA-INV-001'],
  ['products','/admin/products','QA EXAMPLE Cloth 01'],
  ['clients','/clients','client1@example.test'],
  ['applicants','/clients/applicants','applicant@example.test'],
  ['users','/users','client1@example.test'],
  ['houses','/admin/brands','QA EXAMPLE House 01'],
  ['collections','/admin/collections','QA EXAMPLE Collection 1'],
  ['suppliers','/admin/suppliers','QA EXAMPLE Supplier'],
  ['rates','/admin/price-lists','QA-RATE-01'],
  ['stock','/admin/stock','QA-EXAMPLE-1-1'],
  ['report-orders','/reporting/library?r=orders','QA-SO-003'],
  ['shipping','/admin/shipping','QA EXAMPLE Metro'],
  ['purchase-order-detail','/admin/purchase-orders/1','QA-PO-001'],
  ['invoice-detail','/admin/supplier-invoices/1','QA-INV-001'],
  ['new-salesorder','/admin/orders/new','New sales order'],
  ['new-purchaseorder','/admin/purchase-orders/new','New purchase order'],
  ['new-invoice','/admin/supplier-invoices/new','New supplier invoice'],
  ['mirror-clients','/clients/legacy','QA EXAMPLE Historical Client'],
  ['mirror-client-detail','/clients/qa-record','QA EXAMPLE Historical Client'],
  ['mirror-orders','/sales-orders','QA-HIST-SO-001'],
  ['mirror-order-detail','/sales-orders/qa-record','QA-HIST-SO-001'],
  ['xero-connected','/admin/xero','QA EXAMPLE Organisation'],
  ['products-expanded','/admin/products','QA EXAMPLE Cloth 01','Edit','Save product'],
  ['rates-expanded','/admin/price-lists','QA-RATE-01','Edit','Save rate'],
  ['orders-expanded','/admin/orders','QA-SO-001','Open','Save order'],
]
export async function start(stage) {
  if(!['before','after'].includes(stage)) throw new Error('Stage must be before or after')
  if(stage==='after'&&process.env.QA_V2_AFTER_GO!=='1') throw new Error('Final execution is waiting for parent go; set QA_V2_AFTER_GO=1 only after that go.')
  const source=sourceState(stage)
  await mkdir(`${qa}/runtime`,{recursive:true})
  process.env.TMPDIR=`${qa}/runtime`
  const server=spawn(process.execPath,[`${qa}/server.mjs`,stage],{cwd:qa,env:{...process.env,TMPDIR:`${qa}/runtime`},stdio:['ignore','pipe','pipe']})
  let output=''
  await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error(`Vite startup timeout: ${output}`)),30000)
    server.stdout.on('data',chunk=>{output+=chunk;if(output.includes('QA_READY')){clearTimeout(timer);resolve()}})
    server.stderr.on('data',chunk=>{output+=chunk})
    server.on('exit',code=>{clearTimeout(timer);reject(new Error(`Vite exited ${code}: ${output}`))})
  }).catch(e=>{server.kill();throw e})
  const runtime='/workspace/scratch/b4c5a45b264b/qa-browser/runtime'
  const browser=await chromium.launch({executablePath:`${runtime}/chromium`,headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking','--disable-component-update','--no-first-run'],env:{...process.env,LD_LIBRARY_PATH:runtime,TMPDIR:`${qa}/runtime`}}).catch(e=>{server.kill();throw e})
  const origin=`http://127.0.0.1:${stage==='before'?5284:5285}`
  return {browser,origin,source,async close(){try{await browser.close()}finally{server.kill();await new Promise(resolve=>{if(server.exitCode!==null)return resolve();server.once('exit',resolve)});await writeFile(`${qa}/vite-${stage}.log`,output)}}}
}
export async function session(run,{width=1440,height=1000,long=false}={}) {
  const api=createApi({long}),errors=[],consoleErrors=[]
  const context=await run.browser.newContext({viewport:{width,height},locale:'en-NZ',timezoneId:'UTC',serviceWorkers:'block',reducedMotion:'reduce'})
  await context.route('**/*',async route=>{
    const request=route.request(),url=new URL(request.url()),method=request.method()
    if(url.origin===API_ORIGIN) {
      let body=null
      try{body=request.postDataJSON()}catch{}
      const entry={index:api.log.length,method,path:url.pathname,query:url.search,body,contentType:request.headers()['content-type']??null}
      api.log.push(entry)
      const response=scenarioResponse(api.controls,method,url,body,api.data)??api.answer(method,url,body)
      entry.status=response.status??200
      if(!['GET','HEAD','OPTIONS'].includes(method)&&api.controls.delayMs) await new Promise(r=>setTimeout(r,api.controls.delayMs))
      if(method==='GET'&&api.controls.delayReadsMs) await new Promise(r=>setTimeout(r,api.controls.delayReadsMs))
      await route.fulfill({status:entry.status,contentType:'application/json',headers:{'Access-Control-Allow-Origin':run.origin,'Access-Control-Allow-Credentials':'true','Access-Control-Allow-Methods':'GET,HEAD,POST,PATCH,PUT,DELETE,OPTIONS','Access-Control-Allow-Headers':'Accept,Content-Type','Vary':'Origin','X-QA-Fixture':'synthetic-only'},body:response.body==null?'':JSON.stringify(response.body)})
      entry.fulfilled=true
      return
    }
    // Even localhost gets an exact origin + method check. No API proxy fallback.
    if(url.origin===run.origin&&['GET','HEAD'].includes(method)) return route.continue()
    api.external.push({method,url:url.href});return route.abort('blockedbyclient')
  })
  await context.routeWebSocket('**/*',ws=>{api.external.push({method:'WEBSOCKET',url:ws.url()});ws.close()})
  const page=await context.newPage()
  page.setDefaultTimeout(5000)
  page.on('pageerror',e=>errors.push({url:page.url(),message:e.message}))
  page.on('console',m=>{if(m.type()==='error')consoleErrors.push({url:page.url(),message:m.text()})})
  page.on('dialog',async dialog=>{api.native.push({type:dialog.type(),message:dialog.message()});await dialog.dismiss()})
  const go=async(path,marker)=>{await page.goto(`${run.origin}/#${path}`,{waitUntil:'domcontentloaded'});await page.locator('main').waitFor();if(marker) await page.getByText(marker,{exact:false}).first().waitFor({state:'attached'});await page.waitForTimeout(200)}
  return {context,page,api,errors,consoleErrors,go,async close(){await context.close()}}
}
export async function saveJSON(path,data) {await writeFile(path,JSON.stringify(data,null,2)+'\n')}
