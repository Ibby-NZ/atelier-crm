export async function visibleGeometry(locator) {
  return locator.evaluate(el=>{
    const r=el.getBoundingClientRect(),cs=getComputedStyle(el),ancestors=[]
    let left=0,top=0,right=innerWidth,bottom=innerHeight,node=el.parentElement
    while(node){const a=node.getBoundingClientRect(),s=getComputedStyle(node)
      if(/auto|scroll|hidden|clip/.test(s.overflowX)){left=Math.max(left,a.left);right=Math.min(right,a.right)}
      if(/auto|scroll|hidden|clip/.test(s.overflowY)){top=Math.max(top,a.top);bottom=Math.min(bottom,a.bottom)}
      if(s.overflowX!=='visible'||s.overflowY!=='visible')ancestors.push({tag:node.tagName,class:node.className,overflowX:s.overflowX,overflowY:s.overflowY,rect:a.toJSON()})
      node=node.parentElement
    }
    const point=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)
    return {rect:r.toJSON(),visible:r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none',fullyWithinClips:r.left>=left-1&&r.right<=right+1&&r.top>=top-1&&r.bottom<=bottom+1,hit:!!point&&(point===el||el.contains(point)),ancestors}
  })
}
export async function horizontalStrips(page) {
  return page.locator('main').evaluate(main=>{
    const isVisible=el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'}
    const groups=[]
    for(const el of main.querySelectorAll('div,nav,[role="tablist"]')){
      if(!isVisible(el)||el.closest('[role="group"][aria-label="Page actions"]'))continue
      if(el.matches('[role="tablist"]')){groups.push({role:'tablist',text:el.textContent.trim().slice(0,250)});continue}
      const cs=getComputedStyle(el),children=[...el.children]
      // Old SectionTabs consists of direct text links + one static span, with
      // a bottom border on each item. This deliberately excludes filter inputs,
      // report-rail controls, page actions, and ordinary data-row links.
      const tabs=children.filter(c=>c.matches('a,span')&&isVisible(c)&&parseFloat(getComputedStyle(c).borderBottomWidth)>0)
      if(tabs.length>=2&&tabs.some(c=>c.tagName==='A')&&['flex','inline-flex'].includes(cs.display)&&!cs.flexDirection.startsWith('column')){
        groups.push({role:'section-strip',text:tabs.map(t=>t.textContent.trim()),rect:el.getBoundingClientRect().toJSON()})
      }
    }
    return groups
  })
}
export async function pageGeometry(page) {
  return page.evaluate(()=>{
    const main=document.querySelector('main'),rect=main.getBoundingClientRect(),style=getComputedStyle(main)
    const rows=[...main.querySelectorAll('div')].filter(el=>{const cs=getComputedStyle(el);return cs.display==='grid'&&cs.gridTemplateColumns.split(' ').length>=4&&/^(QA-(SO|PO|INV|RATE)-|QA EXAMPLE Cloth)/.test(el.textContent.trim())}).map(el=>{
      const r=el.getBoundingClientRect()
      return {rect:r.toJSON(),cells:[...el.children].map(c=>({text:c.textContent.trim().slice(0,100),rect:c.getBoundingClientRect().toJSON(),scrollWidth:c.scrollWidth,clientWidth:c.clientWidth}))}
    })
    const headings=[...main.querySelectorAll('h1,h2,h3')].map(el=>({text:el.textContent.trim(),rect:el.getBoundingClientRect().toJSON()}))
    const sidebar=document.querySelector('.r-sidenav')
    return {innerWidth,innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight,main:rect.toJSON(),padding:{left:style.paddingLeft,right:style.paddingRight,top:style.paddingTop},headings,rows,fullyVisibleRows:rows.filter(r=>r.rect.top>=62&&r.rect.bottom<=innerHeight).length,sidebar:sidebar?{rect:sidebar.getBoundingClientRect().toJSON(),scrollHeight:sidebar.scrollHeight,clientHeight:sidebar.clientHeight}:null}
  })
}
