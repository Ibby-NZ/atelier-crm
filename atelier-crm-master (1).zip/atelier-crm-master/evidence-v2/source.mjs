import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
import {fileURLToPath} from 'node:url'
export const EXPECTED_BEFORE='6f22dab424e71c38beb47256f920bb8526cbe7df'
export function sourceState(stage) {
  const root=fileURLToPath(new URL(stage==='before'?'../atelier-crm-master/':'../crm-v2/',import.meta.url))
  const git=(...args)=>execFileSync('git',['--no-optional-locks','-C',root,...args],{encoding:'utf8'}).trim()
  const head=git('rev-parse','HEAD'),status=git('status','--porcelain')
  const files=git('ls-files','-z').split('\0').filter(Boolean).sort()
  const digest=createHash('sha256')
  for(const file of files) {digest.update(file+'\0');digest.update(readFileSync(root+file));digest.update('\0')}
  const state={root,head,status,trackedFiles:files.length,trackedSha256:digest.digest('hex'),observedAt:new Date().toISOString()}
  if(stage==='before'&&(head!==EXPECTED_BEFORE||status))throw new Error(`BEFORE must remain clean at ${EXPECTED_BEFORE}: ${JSON.stringify(state)}`)
  return state
}
export function fixtureState() {
  return {sha256:createHash('sha256').update(readFileSync(new URL('./fixtures.mjs',import.meta.url))).digest('hex'),apiOrigin:'http://qa-api.example.test:3001'}
}
