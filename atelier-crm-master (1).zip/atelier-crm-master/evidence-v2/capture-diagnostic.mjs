// Parent-authorized early shell preview. Never writes main AFTER evidence.
import {mkdir} from 'node:fs/promises'
import {qa,start,session,saveJSON} from './harness.mjs'
import {sourceState,fixtureState} from './source.mjs'
const stamp=new Date().toISOString().replace(/[:.]/g,'-'),folder=`${qa}/after-diagnostic-${stamp}`
await mkdir(folder,{recursive:true})
const run=await start('after'),s=await session(run,{width:1440}),report={diagnostic:true,finalAcceptance:false,sourceBefore:run.source,fixtures:fixtureState(),screenshots:[]}
try{
  for(const [name,path,marker]of [['salesorders','/admin/orders','QA-SO-001'],['dashboard','/dashboard','QA-SO-001']]){
    await s.go(path,marker);await s.page.screenshot({path:`${folder}/${name}-1440-viewport.png`});await s.page.screenshot({path:`${folder}/${name}-1440.png`,fullPage:true})
    report.screenshots.push({name,path,capturedAt:new Date().toISOString(),viewportFile:`${name}-1440-viewport.png`,fullPageFile:`${name}-1440.png`});console.log(`${folder}/${name}-1440-viewport.png`)
  }
}finally{report.sourceAfter=sourceState('after');report.errors=s.errors;report.unmatched=s.api.unmatched;report.writes=s.api.writes();report.externalBlocked=s.api.external;report.requests=s.api.log;await saveJSON(`${folder}/manifest.json`,report);await s.close();await run.close()}
if(report.errors.length||report.unmatched.length||report.writes.length)process.exitCode=1
