# Atelier CRM iteration 2 — FINAL QA

**Complete. Ready for packaging.** Final captured application HEAD:
`bb8a37f1659342824852299bb0c039dcf822237e`. Parent subsequently committed
handover documents at `c02d586`; no application delta. Capture manifests retain
the original clean `bb8a37f` states and unchanged start/end source hashes.

| Final suite | Result | Evidence |
|---|---:|---|
| Navigation/browser | **22/22 passed** | `after-populated/checks/results.json` |
| Five-page viewport layout | **10/10 passed** | `after-populated/layout/results.json` |
| Retained sticky headers/footers | **12/12 passed** | `after-populated/sticky/results.json` |
| Targeted filter/money/PO workflows | **8/8 passed** | `after-populated/workflows/results.json` |

No material check is missing from the claimed 22/10/12 counts. Parent's pure
tests/build are separate; this sidecar did not rerun them or the optional full
44-case browser regression suite.

## Captures and source identity

- BEFORE: clean immutable `6f22dab424e71c38beb47256f920bb8526cbe7df`.
- AFTER: clean `bb8a37f1659342824852299bb0c039dcf822237e` at capture start/end.
- Each stage: **28 views × 2 widths = 56 populated views / 112 PNGs**, including
  full-page and viewport variants at 1440×1000 and 1024×1000.
- Capture manifests: `before-populated/manifest.json` and
  `after-populated/manifest.json`. Both report unchanged source during capture.
- Zero capture failures, page exceptions, unknown API calls or writes.
- Synthetic screenshot fixture bytes stayed frozen and identical across stages.
- Old AFTER screenshots/results are preserved as `after-diagnostic-d8a4123/`.
  The earlier shell-only preview remains in its timestamped diagnostic folder.

Priority files in `after-populated/`: `dashboard`, `salesorders`,
`purchaseorders`, `supplierinvoices`, each with `-1440-viewport.png` and
`-1024-viewport.png`. The parent visually reviewed and accepted both widths.

## Final coverage

The browser suite checks 37 sidebar destinations at each desktop width, exactly
one current destination across 30 route cases per width, core Orders links,
header actions, self-create omission, no live actions on the standalone sales
demo, no section strips, keyboard disclosures, same-group reopening via a page
content link, and historical/demo labels. Phone checks cover drawer dialog
semantics, initial focus, Tab/Shift+Tab trap, Escape/focus return, ordinary-link
and wordmark close, plus the phone user menu and navigation to Users.

**Both PO refusal cases** are the delayed `POST /admin/purchase-orders/plan`
503 scenario at 1440 and 1024: the compact summary is initially visible; the
pending panel can be collapsed; the refusal stays outside it and readable.
These are **plan-refusal cases, not PO-list filter GET-refusal tests**. No
separate PO-list filter refusal coverage is claimed.

The eight targeted workflow cases verify Sales URL/draft/apply/clear behavior,
source filtering without another API fetch and honest page counts, exact money
and reconciliation displays, finance fields remaining absent when deleted from
the payload, and successful PO plan/dismiss/replan/generate with exactly the
previewed house IDs and a list reload showing the new synthetic PO.

Sticky gates cover Orders/Rates/Stock headers and Products/Rates/Orders editor
footers, each at both widths. Retained scripts write to `sticky/`, keeping the
five-page layout results separate.

## Corrected QA detector false positive

The initial `d8a4123` run incorrectly classified the two header create links
(New sales order / New purchase order) as a horizontal navigation strip. This
was a QA detector error, with no app change required. Raw failures remain in
`after-diagnostic-d8a4123/checks/results.json`; its focused corrected AFTER
rerun is `checks/strips-rerun.json`. The final full nav suite passed 22/22.

The detector excludes the `[role="group"][aria-label="Page actions"]` group.
The requested BEFORE negative control still detects real strips on **15 pages
at each width**; evidence is
`before-populated/checks/strips-final-negative-control.json`.

## Geometry and tradeoffs

`row-positions.md` / `row-positions.json` contain final BEFORE/AFTER first-row
y/height, every row's top/bottom/height and fully visible row counts. Raw cell
geometry remains in each stage's `layout/results.json`.

| Page | Complete rows at 1440, BEFORE → AFTER | At 1024, BEFORE → AFTER |
|---|---:|---:|
| Sales orders | 5 → 5 | 2 → 3 |
| Purchase orders | 6 → 7 | 2 → 4 |
| Supplier invoices | 6 → 6 | 5 → 4 |
| Products | 4 → 6 | 3 → 3 |

No increased document or measured cell overflow in any of the ten cases.
Document horizontal overflow is zero throughout. At 1440 usable content width
increases from 1088 to 1136 px; at 1024 it remains 728 px. Invoice money-column
overflow disappears; the 1024 row-count tradeoff was visually accepted.
Products at 1024 retains baseline clipping: 18 directly overflowing cells and
9 cells beyond their row, unchanged. These measurements do not assert that every
nested text string is untruncated. Dashboard panels are excluded from list-row
counts and were visually reviewed.

## Isolation and reproduction

All QA writes stay here. Neither app, original `qa`, dependency manifests nor
Vitest were edited. No installs or agents were used. Ports are 5284 (BEFORE) and
5285 (AFTER). Existing Playwright/Vite modules and supplied Chromium are reused;
Chromium's runtime folder supplies `LD_LIBRARY_PATH`. Vite config/cache and
browser profiles are isolated under `qa-v2`.

Only `http://qa-api.example.test:3001` is fixture-fulfilled; unknown API calls
fail with 501. All other origins, other local ports, WebSockets and service
workers are blocked. Exact local Vite GET/HEAD requests are allowed. External
fonts/Userback are blocked, so captures use fallback fonts. Eight isolation
probes passed during setup. No live API/database/email/Xero operation occurred.
Explicit PO scenario POSTs only modify in-memory QA fixtures.

Scripts are standalone browser tools, not Vitest tests. After source is frozen,
run sequentially from `/workspace/scratch/830c7f939e0f`:

```sh
QA_V2_AFTER_GO=1 node qa-v2/capture-populated.mjs after
QA_V2_AFTER_GO=1 node qa-v2/check-browser.mjs after
QA_V2_AFTER_GO=1 node qa-v2/check-layout.mjs after
QA_V2_AFTER_GO=1 node qa-v2/check-layout-regressions.mjs after
QA_V2_AFTER_GO=1 node qa-v2/check-workflows.mjs
node qa-v2/report.mjs
```

Capture scripts refuse to overwrite existing manifests. Preserve the current
final set before any future recapture; never overwrite BEFORE evidence.
