# Viewport row positions

Measured at 1000 px viewport height, with the page at scrollY=0. Complete rows must lie between the 62 px sticky header and the bottom of the viewport. Counts measure density, not text legibility. Cell rectangles/clipping evidence remain in layout/results.json.

| Page | Width | BEFORE first row y / height | BEFORE complete rows | AFTER first row y / height | AFTER complete rows |
|---|---:|---:|---:|---:|---:|
| dashboard | 1440 | — | 0 | — | 0 |
| salesorders | 1440 | 516.0 / 96.0 | 5 | 472.2 / 93.0 | 5 |
| purchaseorders | 1440 | 611.0 / 59.0 | 6 | 449.2 / 69.5 | 7 |
| supplierinvoices | 1440 | 475.0 / 85.0 | 6 | 423.7 / 92.3 | 6 |
| products | 1440 | 500.0 / 117.0 | 4 | 438.2 / 87.0 | 6 |
| dashboard | 1024 | — | 0 | — | 0 |
| salesorders | 1024 | 554.0 / 191.0 | 2 | 569.7 / 132.5 | 3 |
| purchaseorders | 1024 | 720.0 / 126.0 | 2 | 557.7 / 101.0 | 4 |
| supplierinvoices | 1024 | 557.0 / 85.0 | 5 | 532.2 / 111.0 | 4 |
| products | 1024 | 488.0 / 162.0 | 3 | 442.2 / 162.0 | 3 |

Dashboard uses panels/cards; it is deliberately excluded from list-row recognition. All row coordinates are in row-positions.json.
