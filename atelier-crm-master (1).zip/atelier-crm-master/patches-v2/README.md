# Iteration 2 review patches

These ten patches reproduce the delivered source from iteration 1 at local baseline `6f22dab424e71c38beb47256f920bb8526cbe7df`. They do not apply directly to the original uploaded ZIP: that archive predates the first iteration. The full revised source is also supplied and includes both iterations.

Apply patches in numerical order to a clean, matching iteration-1 checkout. They were applied to an isolated index and reproduced delivery tree `d50ff88eed0899ff775f103df438b657360ef3e2` exactly. Final source revision: `c02d586e88fdb59a6a373565e4c9e8ce598f5f05`. Verified application revision before the documentation-only final commit: `bb8a37f1659342824852299bb0c039dcf822237e`.

For PR review, group navigation changes together; review Dashboard, Sales orders, Purchase orders and Supplier invoices independently. Fold their sizing and feedback follow-ups into the corresponding review. Every commit passed npm test followed by npm run build. No remote was supplied, so these are local review patches, not published PRs.
