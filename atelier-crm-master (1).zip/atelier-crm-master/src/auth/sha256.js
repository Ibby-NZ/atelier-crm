// SHA-256, pure JavaScript, no dependencies.
//
// Used by break-glass sign-in (./breakGlass.js) to compare a typed passphrase
// against a digest baked into the build. Deliberately NOT `crypto.subtle`:
// WebCrypto is only exposed in a secure context, so on a plain-http staging box
// `crypto.subtle` is `undefined` and the emergency login would fail exactly
// where it is most likely to be needed. A hand-rolled digest also runs
// unchanged under `vitest` in Node with no environment branch.
//
// This is a digest, not a password KDF — see the note at the top of
// ./breakGlass.js about why the passphrase has to be long and random.

// Round constants: the fractional parts of the cube roots of the first 64
// primes (FIPS 180-4 §4.2.2).
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
  0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
  0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
  0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
  0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
  0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
])

const INITIAL = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
])

const rotr = (x, n) => ((x >>> n) | (x << (32 - n))) >>> 0

// Pad to a whole number of 64-byte blocks: a 0x80 byte, zeroes, then the
// message length in bits as a 64-bit big-endian integer.
function padded(bytes) {
  const blocks = Math.ceil((bytes.length + 9) / 64)
  const out = new Uint8Array(blocks * 64)
  out.set(bytes)
  out[bytes.length] = 0x80
  const view = new DataView(out.buffer)
  const bits = bytes.length * 8
  view.setUint32(out.length - 8, Math.floor(bits / 0x100000000))
  view.setUint32(out.length - 4, bits >>> 0)
  return out
}

// UTF-8 string → lowercase 64-character hex digest.
export function sha256Hex(text) {
  const message = padded(new TextEncoder().encode(String(text)))
  const view = new DataView(message.buffer)
  const h = Uint32Array.from(INITIAL)
  const w = new Uint32Array(64)

  for (let offset = 0; offset < message.length; offset += 64) {
    for (let t = 0; t < 16; t += 1) w[t] = view.getUint32(offset + t * 4)
    for (let t = 16; t < 64; t += 1) {
      const x = w[t - 15]
      const y = w[t - 2]
      const s0 = (rotr(x, 7) ^ rotr(x, 18) ^ (x >>> 3)) >>> 0
      const s1 = (rotr(y, 17) ^ rotr(y, 19) ^ (y >>> 10)) >>> 0
      w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0
    }

    let [a, b, c, d, e, f, g, hh] = h
    for (let t = 0; t < 64; t += 1) {
      const S1 = (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) >>> 0
      const ch = ((e & f) ^ (~e & g)) >>> 0
      const temp1 = (hh + S1 + ch + K[t] + w[t]) >>> 0
      const S0 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) >>> 0
      const maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0
      const temp2 = (S0 + maj) >>> 0
      hh = g
      g = f
      f = e
      e = (d + temp1) >>> 0
      d = c
      c = b
      b = a
      a = (temp1 + temp2) >>> 0
    }

    h[0] = (h[0] + a) >>> 0
    h[1] = (h[1] + b) >>> 0
    h[2] = (h[2] + c) >>> 0
    h[3] = (h[3] + d) >>> 0
    h[4] = (h[4] + e) >>> 0
    h[5] = (h[5] + f) >>> 0
    h[6] = (h[6] + g) >>> 0
    h[7] = (h[7] + hh) >>> 0
  }

  let hex = ''
  for (let i = 0; i < 8; i += 1) hex += h[i].toString(16).padStart(8, '0')
  return hex
}

// Length-independent equality over two hex digests. Both are always 64 chars
// here, so the length is not a secret; the loop exists so a partial match is
// not measurably slower than a total mismatch.
export function digestsMatch(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}
