// The rules behind AdminSamples, kept out of the .jsx so they can be tested.
// This repo has no jsdom, so a component cannot be rendered — the house pattern
// is a plain .js beside the screen (see adminSuppliers.js) holding everything
// that is a decision rather than a layout.
//
// The register answers three questions: what is on the shelf, what is out, and
// what is late back. Four decisions shape how this screen may answer them, and
// each one is a correctness rule rather than a style choice:
//
//   - **OVERDUE COMES FROM THE API AND IS NEVER RECOMPUTED HERE.** The API
//     derives it at read time as `returned_at IS NULL AND due_back_at < now()`
//     and hands it over as `sample.overdue`. A browser that compared the dates
//     itself would answer with the DEVICE's clock and time zone — a showroom
//     laptop set an hour fast would chase a client whose sample is not late —
//     and would disagree with every filter and export the API produces. This
//     module reads the boolean and nothing else; there is no date arithmetic in
//     it, and `adminSamples.test.js` asserts that against the source.
//   - **Nothing from the Dynamics cutting staging table is ever displayed.**
//     Its free-text staff column is the back office's scratchpad and carries
//     third parties' names, emails, phones and home addresses in current rows.
//     The register reads `/admin/samples` only; `sample.notes` is the platform's
//     own staff-typed field and is a different thing entirely. A source scan
//     holds both screens to it.
//   - **`out` is not a status a form may write.** It is the one status that
//     ASSERTS an open loan exists, and only the check-out route writes both
//     tables in the transaction that makes it true. The API refuses it at the
//     schema AND in the module; the form must not offer it, or staff meet a 400
//     for asking a reasonable-looking question.
//   - **A movement is a verb, never a status change.** Check-out and check-in
//     are their own endpoints for that reason, and the screen offers whichever
//     one the row's open loan makes possible.

import { bodyFrom } from '../admin/drafts.js'

export const SAMPLES_PATH = '/admin/samples'

// The API pages at 200. 25 keeps the register scannable on a laptop; the pager
// is the kit's.
export const SAMPLE_LIST_LIMIT = 25

/** `/admin/samples/12`. One place, so a typo is a failing test not a 404. */
export const samplePath = (id) => `${SAMPLES_PATH}/${id}`

/** The scanner's read, shared with US-009's SampleScanner. Exact, 200 or 404. */
export const byBarcodePath = (barcode) =>
  `${SAMPLES_PATH}/by-barcode/${encodeURIComponent(barcode ?? '')}`

export const checkOutPath = (sample) => `${samplePath(sample?.id)}/check-out`
export const checkInPath = (sample) => `${samplePath(sample?.id)}/check-in`

/**
 * Which lifecycle verb a row offers. An archived sample offers `restore`; a live
 * one offers `archive`. Both are POSTs to the same path shape.
 *
 * @param {{ archived_at?: string|null }} sample
 * @returns {'archive'|'restore'}
 */
export const archiveVerb = (sample) => (sample?.archived_at ? 'restore' : 'archive')

/** The endpoint the row's toggle posts to. */
export const archiveTogglePath = (sample) => `${samplePath(sample?.id)}/${archiveVerb(sample)}`

/**
 * The endpoint "Archive instead" posts to — ALWAYS archive. It is offered on a
 * REFUSED delete, so pointing it at the toggle would answer a request to remove
 * the row by restoring it. Same split adminCatalogue.js draws.
 */
export const archiveInsteadPath = (sample) => `${samplePath(sample?.id)}/archive`

// The full vocabulary `samples_status_check` holds — what the LIST may filter
// on. `out` is here because "what is out" is the register's headline question,
// even though nothing on this screen may write it.
export const SAMPLE_STATUSES = Object.freeze(['in_library', 'out', 'missing', 'retired'])

// What a create or a PATCH may write: everything except `out`. DERIVED from the
// vocabulary rather than re-typed, exactly as the API derives
// WRITABLE_SAMPLE_STATUSES from SAMPLE_STATUSES — so a status added to one set
// cannot be missing from the other.
export const WRITABLE_SAMPLE_STATUSES = Object.freeze(
  SAMPLE_STATUSES.filter((status) => status !== 'out')
)

// The column stores lower_snake_case; nobody reads "in_library" as a place.
export const STATUS_LABELS = Object.freeze({
  in_library: 'In the library',
  out: 'Out on loan',
  missing: 'Missing',
  retired: 'Retired',
})

export const statusLabel = (status) => STATUS_LABELS[status] ?? status ?? '—'

// Mirrors SAMPLE_UPDATE_COLUMNS in atelier-api's src/samples/admin-samples.js —
// the frozen whitelist a PATCH may write. A key declared here and missing there
// is stripped by Ajv's removeAdditional before the handler sees it, so it would
// silently save nothing.
//
// `barcode` IS editable: it is a printed tag that can be mistyped and nothing
// references it (`sample_loans.sample_id` points at the row's id), so a
// correction is safe and a collision is the same 409 the create answers with.
// It stays `required` HERE because this list drives the EDIT diff: the column
// is NOT NULL, so clearing it on an existing row must be refused in the form
// rather than surface as a 400. The create path is different — see
// createSampleBody below.
export const SAMPLE_FIELDS = Object.freeze([
  { key: 'barcode', label: 'Barcode', kind: 'text', required: true },
  { key: 'label', label: 'Label', kind: 'text' },
  { key: 'sample_type', label: 'Type', kind: 'text' },
  { key: 'location', label: 'Shelf location', kind: 'text' },
  { key: 'status', label: 'Status', kind: 'enum' },
  { key: 'colourway_id', label: 'Colourway', kind: 'ref' },
  { key: 'supplier_id', label: 'Supplier', kind: 'ref' },
  { key: 'showroom_id', label: 'Showroom', kind: 'ref' },
  { key: 'notes', label: 'Notes', kind: 'text' },
])

// What a sample cost (C18) — the MANUAL fallback beside the automatic flow
// (receipting a priced PO sample line writes these by barcode). `decimal`, not
// `money`: the figure is in the supplier's own currency at numeric(12,4), never
// cents. The currency is `text`, not `upper` — the API deliberately holds no
// CHECK on it ("a sample can be bought from anyone in anything"), so a
// three-letter-code rule here would refuse what the API accepts.
export const SAMPLE_COST_FIELDS = Object.freeze([
  { key: 'unit_cost', label: 'Value', kind: 'decimal' },
  { key: 'cost_currency', label: 'Value currency', kind: 'text' },
])

/**
 * The fields the signed-in user's form works over.
 *
 * The cost pair appears ONLY with finance visibility, and this is not
 * cosmetic: the API deletes the keys from every response a non-finance login
 * gets AND 403s a write that names them — Ajv does not strip a DECLARED key —
 * so a form that always carried them would 403 every save (bodyFrom sends every
 * declared field, blanks as null included). The split keeps a showroom login's
 * register fully usable; the 403 stays the API's gate if anything drifts.
 *
 * @param {boolean} finance useAccess().finance — the API's derived report_access
 * @returns {ReadonlyArray<object>}
 */
export const sampleFieldsFor = (finance) =>
  finance === true ? Object.freeze([...SAMPLE_FIELDS, ...SAMPLE_COST_FIELDS]) : SAMPLE_FIELDS

export const NEW_SAMPLE = Object.freeze({
  barcode: '',
  label: '',
  sample_type: '',
  location: '',
  status: '',
  colourway_id: '',
  supplier_id: '',
  showroom_id: '',
  notes: '',
  // Read only by a finance form (sampleFieldsFor) — bodyFrom never touches a
  // key its field list does not declare, so these blanks are inert without the
  // grant.
  unit_cost: '',
  cost_currency: '',
})

/**
 * Build a create body from the register form. Unlike the edit path (which
 * diffs against SAMPLE_FIELDS, where barcode is required — the column is NOT
 * NULL), a blank barcode here is not an error: it is the request for a
 * server-minted tag, expressed by leaving the key out of the body entirely
 * (W20-US-002: the API refuses both `''` and an explicit null so an empty
 * input box cannot mint a tag by accident; absence is the one deliberate
 * spelling — which is exactly why bodyFrom's blanks-as-null shape cannot be
 * used raw here).
 *
 * `fields` is the SIGNED-IN USER's field list — pass `sampleFieldsFor(finance)`
 * so a finance login's Value inputs reach the body and everyone else's body
 * never names the cost keys the API would 403 (barcode is stripped from
 * whichever list arrives; it is handled by hand below).
 *
 * @param {object} draft
 * @param {ReadonlyArray<object>} [fields]
 * @returns {{ body: object }|{ error: string }}
 */
export function createSampleBody(draft = {}, fields = SAMPLE_FIELDS) {
  const built = bodyFrom(draft, fields.filter((field) => field.key !== 'barcode'))
  if (built.error) return built
  // `status` is the second key that must be ABSENT rather than null: the create
  // schema types it a plain enum string (the nullable columns are typed
  // ['string','null'], this one is not), so bodyFrom's blank-as-null answers
  // "body/status must be equal to one of the allowed values" — a 400 behind
  // the untouched '—' option. Absent, the column's default (`in_library`)
  // applies, which is exactly what an unchosen status means.
  if (built.body.status == null) delete built.body.status
  const barcode = typeof draft.barcode === 'string' ? draft.barcode.trim() : ''
  if (barcode !== '') built.body.barcode = barcode
  return built
}

/**
 * The toast after a create. When the form sent no barcode the server minted
 * one, and the flash is the office's ONE chance to read the new tag off the
 * screen while the object is still in hand — there is no mint endpoint and no
 * other moment the number is called out.
 *
 * @param {object} sentBody  the body createSampleBody built
 * @param {{ barcode?: string }} sample  the row the API answered with
 * @returns {string}
 */
export function createdSampleNote(sentBody = {}, sample = {}) {
  if (!('barcode' in sentBody) && sample.barcode) {
    return `Registered with the new barcode ${sample.barcode} — label the sample now.`
  }
  return `${describeSample(sample) ?? 'Sample'} registered.`
}

/**
 * A sample's recorded value, in words that keep NULL and 0 different facts.
 *
 * The key being ABSENT is the finance gate (the API deletes it, never nulls
 * it) and prints as nothing; `null` is "nobody recorded a cost"; 0 is "free of
 * charge, and we know it" — the client's free hangers. `Number(null)` is 0, so
 * the branch order here is exactly the trap this platform documents.
 *
 * @param {object} [sample]
 * @returns {string}
 */
export function sampleCostText(sample = {}) {
  if (!Object.hasOwn(sample, 'unit_cost')) return ''
  if (sample.unit_cost == null) return 'No cost recorded'
  const value = Number(sample.unit_cost)
  if (!Number.isFinite(value)) return 'No cost recorded'
  if (value === 0) return 'Free of charge'
  return sample.cost_currency ? `${value} ${sample.cost_currency}` : String(value)
}

/**
 * The list row's version: only a value somebody RECORDED (0 included — a free
 * hanger is a recorded fact). "No cost recorded" on every unpriced row would
 * drown the register in the ordinary state most of the library is in; the
 * editor is where that reads as information.
 *
 * @param {object} [sample]
 * @returns {string}
 */
export const recordedCostText = (sample = {}) =>
  Object.hasOwn(sample, 'unit_cost') && sample.unit_cost != null ? sampleCostText(sample) : ''

/**
 * The list filters, in the shape buildListQuery expects.
 *
 * Every optional filter is passed as `value || null` so it VANISHES when unset:
 * buildListQuery drops null/undefined/empty, and an "All" select forwarded as an
 * empty string would become `status=`, which the endpoint's enum answers with a
 * 400 that kills the WHOLE list rather than one filter.
 *
 * `overdue` is TRI-STATE and must stay so: absent leaves the list alone, true is
 * the chase list, false is "not late back" — out on time OR on the shelf. It is
 * therefore not passed through `|| null` (that would erase the `false` case);
 * only the empty selection becomes null.
 *
 * @param {{ term?: string, status?: string, showroomId?: string|number,
 *   supplierId?: string|number, overdue?: string, showArchived?: boolean }} [state]
 */
export function sampleFilters({
  term = '',
  status = '',
  showroomId = '',
  supplierId = '',
  overdue = '',
  showArchived = false,
} = {}) {
  return {
    q: term,
    status: status || null,
    showroom_id: showroomId || null,
    supplier_id: supplierId || null,
    overdue: overdue === '' ? null : overdue === 'true',
    include_archived: showArchived || null,
  }
}

/**
 * The row's name in the confirm dialog. The barcode identifies a sample across
 * the whole register — it is the unique column and the tag on the object — where
 * a label ("Atlas hanger") is freely duplicated.
 *
 * @param {{ barcode?: string, label?: string }} sample
 * @returns {string|undefined}
 */
export function describeSample(sample) {
  const barcode = typeof sample?.barcode === 'string' ? sample.barcode.trim() : ''
  if (barcode === '') return undefined
  const label = typeof sample?.label === 'string' ? sample.label.trim() : ''
  return label === '' ? barcode : `${barcode} (${label})`
}

/**
 * Which movement the row offers. An open loan means it is out and can come back;
 * no open loan means it can go out.
 *
 * Derived from `open_loan`, not from `status`: the loan row is what the movement
 * writes and what the one-open-loan index guards, and the two can only disagree
 * if something has gone wrong — in which case the loan is the truth.
 *
 * @param {{ open_loan?: object|null }} sample
 * @returns {'check-out'|'check-in'}
 */
export const movementVerb = (sample) => (sample?.open_loan ? 'check-in' : 'check-out')

/**
 * How a row's loan state reads, taking `overdue` from the API verbatim.
 *
 * There is no date comparison here and there must never be one — see the module
 * header. `sample.overdue` is the API's derivation; this function only chooses
 * words for it.
 *
 * @param {{ overdue?: boolean, open_loan?: {holder_name?: string}|null }} sample
 * @returns {{ text: string, tone: 'danger'|'ink'|'muted' }}
 */
export function loanState(sample) {
  const loan = sample?.open_loan ?? null
  if (!loan) return { text: 'On the shelf', tone: 'muted' }
  const holder = typeof loan.holder_name === 'string' ? loan.holder_name.trim() : ''
  const who = holder === '' ? 'someone' : holder
  // The API's boolean, verbatim — never a clock reading taken in this browser.
  return sample.overdue === true
    ? { text: `Overdue — with ${who}`, tone: 'danger' }
    : { text: `Out with ${who}`, tone: 'ink' }
}

/** One line of catalogue identity for the row's second line. */
export function sampleMeta(sample = {}) {
  const parts = [sample.brand_name, sample.product_name, sample.colourway_name]
    .map((part) => (typeof part === 'string' ? part.trim() : ''))
    .filter(Boolean)
  if (parts.length) return parts.join(' · ')
  // A sample with no catalogue link is normal, not broken: plenty predate the
  // catalogue or come from a house Atelier does not stock, and `label` is what
  // identifies those.
  return sample.label ? 'Not linked to a design' : 'No design and no label'
}

/**
 * Build a check-out body from the counter form.
 *
 * `holder_name` is the only required field. `due_back_at` is deliberately
 * optional: plenty of samples go out with no date agreed, and inventing one
 * would make them overdue on a deadline nobody set. A blank date is omitted
 * rather than sent as null — the API's schema types it a string, so an explicit
 * null is a 400.
 *
 * `trade_account_id` is the company link, and it is optional the same way: the
 * API types it `integer`, so a blank is omitted, never sent as null or ''. The
 * name still stands alone for a walk-in (an architect, a stylist, staff) — the
 * link only makes the loan filterable by company on the outstanding queue and
 * gives the reminder flow an address to suggest.
 *
 * @param {{ holder_name?: string, due_back_at?: string, notes?: string,
 *   trade_account_id?: string|number }} draft
 * @returns {{ body: object }|{ error: string }}
 */
export function checkOutBody(draft = {}) {
  const holder = typeof draft.holder_name === 'string' ? draft.holder_name.trim() : ''
  if (holder === '') {
    return { error: 'Who is taking it? A loan that cannot say who has the sample answers nothing.' }
  }
  const body = { holder_name: holder }
  const account = draft.trade_account_id == null ? '' : String(draft.trade_account_id).trim()
  if (account !== '') {
    const id = Number(account)
    // The picker only produces real ids, so this refusal is for a state bug,
    // not a person — but sending it anyway would be a 400 with a worse sentence.
    if (!Number.isInteger(id) || id < 1) {
      return { error: 'That trade account selection is not valid. Clear it and pick again.' }
    }
    body.trade_account_id = id
  }
  const due = typeof draft.due_back_at === 'string' ? draft.due_back_at.trim() : ''
  if (due !== '') body.due_back_at = due
  const notes = typeof draft.notes === 'string' ? draft.notes.trim() : ''
  if (notes !== '') body.notes = notes
  return { body }
}

export const EMPTY_CHECK_OUT = Object.freeze({
  holder_name: '',
  due_back_at: '',
  notes: '',
  // The picker's pair: the id is what the API gets, the name is what the form
  // shows for it. Both blank until a company is picked.
  trade_account_id: '',
  trade_account_name: '',
})

/**
 * Fold a picked trade account into the check-out draft, or clear the link.
 *
 * Picking also fills a BLANK holder name with the company's, because "the
 * company took it" is the common case at the counter — but it never overwrites
 * a name somebody typed: `holder_name` is the snapshot of who actually has the
 * thing, and the account is only the current owner of the relationship.
 *
 * @param {object} draft   the current check-out form state
 * @param {{ id?: number|string, name?: string }|null} account null clears the link
 * @returns {object}
 */
export function withTradeAccount(draft = {}, account = null) {
  if (!account || account.id == null) {
    return { ...draft, trade_account_id: '', trade_account_name: '' }
  }
  const next = {
    ...draft,
    trade_account_id: String(account.id),
    trade_account_name: typeof account.name === 'string' ? account.name : '',
  }
  const holder = typeof draft.holder_name === 'string' ? draft.holder_name.trim() : ''
  if (holder === '' && next.trade_account_name !== '') {
    next.holder_name = next.trade_account_name
  }
  return next
}

/**
 * Is this the by-barcode lookup saying "no such sample"? A 404 there is an
 * ANSWER, not a failure: the endpoint is an exact match on the unique column
 * and it found nothing, so the scanner offers the register instead of an error
 * line. Anything else — a network drop, a 500 — is a failure and reads through
 * messageOf as usual.
 *
 * @param {{ status?: number }|unknown} error
 * @returns {boolean}
 */
export const isNotFound = (error) => error?.status === 404
